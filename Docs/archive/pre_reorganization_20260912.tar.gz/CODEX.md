# Karpathy Guidelines

Behavioral guidelines for writing, reviewing, and refactoring code. They favor
caution over speed when the task is not trivial.

## Think Before Coding

- State assumptions explicitly. Do not hide confusion.
- When multiple interpretations materially affect the result, present them or
  ask for direction rather than choosing silently.
- Prefer the simpler approach and call out relevant tradeoffs.

## Simplicity First

- Write the minimum code that solves the requested problem.
- Do not add speculative features, abstractions, configurability, or handling
  for impossible scenarios.
- If a solution is substantially more complex than necessary, simplify it.

## Surgical Changes

- Change only lines needed for the request and match the surrounding style.
- Do not refactor, reformat, or remove unrelated code; mention such findings
  instead.
- Remove only imports, variables, or functions made unused by the current
  change.

## Goal-Driven Execution

- Define concrete, verifiable success criteria before implementation.
- For multi-step work, state a brief plan and a verification check per step.
- Run proportionate verification and report the result.
