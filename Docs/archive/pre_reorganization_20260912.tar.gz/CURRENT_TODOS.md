# Current Todos

## Active

- [ ] **Protein + RNA eğitim smoke testi:** Hazır canonical protein cache'i ve
  canonical RNA cache'ini eğitim config'ine bağla. Önce kısa
  domain-bazlı kontrolleri, sonra multidomain smoke train'i çalıştır; CB/C1',
  backbone, gerçek sidechain/base, V recall ve adım süresi gate'lerini raporla.

- [ ] **Metabolit entegrasyonu:** Metabolit acilacaksa `bond_edge_index` alaninin cross-modal PyG collate hatasi cozulmeli. Metabolit kapali PDB + RNA + UniMol egitimi icin bu madde engel degil.

## Later

- [ ] **Compact atom vocabulary deneyi:** Virtual-template A/B deneyleri
  tamamlandiktan sonra mevcut sparse `0..120` id duzenini ayri bir feature
  olarak compact `14-class` duzenle karsilastir: `0=mask`, `1..11=common`,
  `12=rare`, `13=virtual`. Sadece `119/120 -> 4/5` tasimasi yapma. Loader
  migration, atom embedding, MLM head, Gaussian edge-pair indeksleri, metrics,
  downstream checkpoint uyumu ve eski/yeni loss olcegi icin bagimsiz A/B ve
  checkpoint-migration plani gerektirir. Virtual geometri degisikligiyle ayni
  deneyde birlestirme.

## Completed

- [x] **RNA canonical final cache:** 67 adet canonical 23-slot shard üretildi.
  Toplam `12,869` benzersiz graph, `225,036,797` node ve
  `10,744,071,169` edge doğrulandı. Metadata, exact manifest ve index map
  oluşturuldu; görünür V koordinatları canonical slot noktalarına taşındı ve
  spatial kenarlar yeniden kuruldu. P-only ve mirror/L-RNA dışlamaları ile
  LazyUniversalDataset yükleme kontrolü geçti.
