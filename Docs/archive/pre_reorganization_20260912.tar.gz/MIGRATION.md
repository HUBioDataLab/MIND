# MIND Sunucu Taşıma ve 1M Protein İşleme Kılavuzu

Bu belge yalnızca operasyonel taşıma sırasını tanımlar. Eğitim sonucuna göre hangi
kodun `main`e alınacağı ayrı bir karardır. Taşıma başlamadan önce seçilen kodun Git
SHA'sı ve protein temsil biçimi sabitlenmelidir; aksi halde 1M protein verisi yeniden
işlenmek zorunda kalabilir.

Komutlardaki değerleri iki sunucuya göre bir kez ayarlayın:

```bash
export MIND_NEW_HOST=new-server.example
export MIND_NEW_USER=yusuf
export MIND_NEW_PARENT=/srv/yusuf
```

Yeni sunucuda hedef düzen şöyledir:

```text
$MIND_NEW_PARENT/
├── MIND/
└── data/
    ├── proteins/
    │   ├── afdb_clusters/
    │   ├── raw_structures_hq_40k/
    │   ├── raw_structures_1m_1024/
    │   ├── processed_14atom_chunk_0/ ... _9/
    │   └── processed_14atom_1m_chunk_0/ ... _99/
    ├── rna/
    │   ├── raw_structures/
    │   ├── final_23slot_chunk_*/
    │   ├── june_equivalent_23slot_v2/
    │   └── manifests/
    ├── rna_small/
    ├── small_molecules/unimol/
    └── metabolites/                 # Şimdilik eğitimde kapalı
```

`chunk_dir` tek bir fiziksel klasör olmak zorunda değildir. Kod bunu çoğu veri
kümesinde `..._chunk_0`, `..._chunk_1` gibi kardeş dizinleri bulmak için önek
olarak kullanır.

## 1. Taşımadan önce sürümü dondur

Önce aktif yazma yapan eğitim veya veri işleme süreci olmadığını doğrula. Eğitim
süreci için yalnızca PID görmek yeterli değildir: Python worker'ın tam komutu ve
output dizini, GPU PID'si ve logun iki farklı gözlemde ilerleyip ilerlemediği birlikte
kontrol edilmelidir.

Ardından çalışma ağacını kaydet:

```bash
cd /home/yusuf/MIND
git status --short
git diff --check
git diff --stat
git rev-parse HEAD
```

Commit edilmemiş işler incelenip seçilen değişiklikler odaklı commitlere ayrılmalı,
test edilmeli ve ancak bundan sonra `main`e gönderilmelidir. Protein/RNA sabit-slot
kararı artık `Docs/features/VIRTUAL_ATOMS_IN_GRAPH_TRANSFORMER.md` belgesindeki
fiziksel ESA + latent backbone slot readout sözleşmesidir. Bu kod küçük testleri
geçse de gerçek `.pt` sample ve kısa GPU smoke'u geçmeden 1M işleme veya
production eğitim başlatılmamalıdır.

Yeni sunucuda aynı sürümü kurmak için commit SHA'yı ayrıca kaydet:

```bash
git rev-parse HEAD > /tmp/mind_migration_git_sha.txt
```

## 2. Gerçek veri envanteri

| Veri | Eski sunucu kaynağı | Yeni sunucu hedefi |
|---|---|---|
| 1M protein ham yapılar | `/media/ubuntu/8TB/yusuf/protein_data/raw_structures_1m_1024/` | `data/proteins/raw_structures_1m_1024/` |
| Protein manifestleri | `/media/ubuntu/8TB/yusuf/protein_data/afdb_clusters/` | `data/proteins/afdb_clusters/` |
| 40k protein ham yapılar | `/home/yusuf/data/proteins/raw_structures_hq_40k/` | `data/proteins/raw_structures_hq_40k/` |
| 40k işlenmiş protein | `/home/yusuf/data/proteins/processed_14atom_chunk_*` ve `/home/yusuf/data/proteins/processed_14atom_index_map.json` | `data/proteins/` |
| RNA ham yapılar | `/media/ubuntu/8TB/arya/rna_data/` | `data/rna/raw_structures/` |
| Tam RNA 23-slot | `/media/ubuntu/8TB/yusuf/mind_virtual_v1/rna/final_23slot_chunk_*` ve aynı dizindeki index/validation/manifest dosyaları | `data/rna/` |
| Eğitimde kullanılan June-equivalent RNA | `/media/ubuntu/8TB/yusuf/mind_virtual_v1/rna/june_equivalent_23slot_v2/` | `data/rna/june_equivalent_23slot_v2/` |
| Küçük RNA doğrulama seti | `/home/yusuf/data/rna_small/` | `data/rna_small/` |
| UniMol | `/media/ubuntu/8TB/arin/unimol_pyg_full/universal_unimol_chunk_*` | `data/small_molecules/unimol/` |
| Metabolit, isteğe bağlı | `/media/ubuntu/8TB/ege/processed/` | `data/metabolites/` |
| Eğitim logları | `/home/yusuf/MIND/logs/` | `MIND/logs/` |
| Checkpoint/çıktılar | `/home/yusuf/MIND/outputs/` | `MIND/outputs/` |

Mevcut çok-domain eğitimini yeniden üretmek için RNA tarafında
`june_equivalent_23slot_v2` kullanılmalıdır. `final_23slot_chunk_*` arşiv olarak
taşınabilir fakat doğrudan yerine konmamalıdır; önceki denetimde tam RNA setinin
atom hacmi yaklaşık 12.4 kat daha büyük çıkmıştır.

Bu listedeki yollar eski sunucu envanteridir. Aktarıma başlamadan önce her kaynak
için `test -d <yol>` ve kritik manifest için `test -f <yol>` çalıştırılmalıdır.
Bu dokümanın hazırlandığı mevcut çalışma ortamında YAML'ların işaret ettiği
protein ve RNA `.pt` dizinleri bağlı değildi; bulunmayan bir yolu boş dizin gibi
taşımaya çalışma.

Kaynak ve hedefte kapasite ile inode sayısını taşıma öncesi kontrol et:

```bash
df -h
df -ih
du -sh /home/yusuf/MIND/outputs /home/yusuf/MIND/logs
```

## 3. Çalışan ortamı aynen aktar

`GET/env.yml` güncel çalışan ortamı eksiksiz temsil etmiyor. Tahmini paket kurulumu
yerine eski sunucudaki gerçek ortamı dışa aktar:

```bash
mkdir -p /tmp/mind_migration_env
conda env export -n mind_esa3d --no-builds \
  > /tmp/mind_migration_env/mind_esa3d.environment.yml
/opt/anaconda3/envs/mind_esa3d/bin/python -m pip freeze \
  > /tmp/mind_migration_env/mind_esa3d.pip-freeze.txt

rsync -a /tmp/mind_migration_env/ \
  "${MIND_NEW_USER}@${MIND_NEW_HOST}:/tmp/mind_migration_env/"
```

Mevcut ortamda doğrulanmış ana sürümler:

- Python 3.11.13
- PyTorch 2.5.0+cu118
- PyTorch Geometric 2.6.1
- PyTorch Lightning 2.5.2
- NumPy 1.26.4
- Biopython 1.85
- RDKit 2025.3.3

Yeni sunucunun NVIDIA sürücüsü PyTorch'un CUDA 11.8 build'ini desteklemelidir.
Ortam dosyasını yeni sunucuya taşıdıktan sonra:

```bash
conda env create -n mind_esa3d \
  -f /tmp/mind_migration_env/mind_esa3d.environment.yml
conda activate mind_esa3d
python -m pip install pytest
```

`pytest` eski ortamda kurulu değildi; taşıma sonrası testler için açıkça eklenmiştir.
Kurulum sırasında `torchvision` sembol uyumsuzluğu veya `bitsandbytes` CUDA uyarısı
çıkarsa bunları görmezden gelmeyip aynı PyTorch/CUDA matrisiyle yeniden kur.

Ortamı doğrula:

```bash
python - <<'PY'
import Bio
import numpy
import pytorch_lightning
import rdkit
import torch
import torch_geometric

print("python/torch:", torch.__version__)
print("cuda available:", torch.cuda.is_available())
print("cuda runtime:", torch.version.cuda)
print("pyg:", torch_geometric.__version__)
print("lightning:", pytorch_lightning.__version__)
print("numpy:", numpy.__version__)
print("biopython:", Bio.__version__)
print("rdkit:", rdkit.__version__)
PY
```

## 4. Kodu aynı committen kur

Yeni sunucuda:

```bash
cd "$MIND_NEW_PARENT"
git clone <MIND_GIT_REMOTE> MIND
cd MIND
git fetch --all --tags
git checkout <KAYDEDILEN_GIT_SHA>
```

Özel anahtarlar, W&B kimlik bilgileri ve makineye özgü gizli dosyalar Git'e
konmamalıdır; yeni sunucuda ayrı kurulmalıdır.

## 5. Veriyi taşı

> [!NOTE]
> **Neden ham veriyi aktarıp `.pt`'leri yeni sunucuda üretiyoruz?**
> 1M proteinin ham PDB verisi **~160 GB** iken, 100 chunk PyG `.pt` çıktısı **~1.5 TB** tutmaktadır.
> 1.5 TB işlenmiş veriyi ağdan aktarmak yerine 160 GB ham veriyi aktarıp `.pt` üretimini
> yeni sunucunun işlemcilerinde yerel olarak yapmak hem transfer süresini ~10 kat kısaltır
> hem de ağ/disk yükünü azaltır.

> [!IMPORTANT]
> **Çözüm: Sunucuda tmux kullanmaktır.**
> Yerel bilgisayarınızı kapattığınızda veya SSH bağlantınız koptuğunda aktarımın
> kesilmemesi için aktarım komutları kaynak sunucuda (`anzu`) bir `tmux` oturumu
> içerisinde çalıştırılmalıdır:
> ```bash
> tmux new -s veri_aktarimi
> # Aktarım komutunu başlatın (tar pipe veya rsync)
> # Ctrl + B tuşlarına basıp ardından D tuşuna basarak ayrılın (detach)
> # Artık yerel bilgisayarınızı güvenle kapatabilir veya uyutabilirsiniz.
> # Durumu tekrar izlemek için sunucuya bağlanıp:
> tmux attach -t veri_aktarimi
> ```

Yeni sunucuda hedefleri oluştur:

```bash
mkdir -p \
  "$MIND_NEW_PARENT/data/proteins/raw_structures_1m_1024" \
  "$MIND_NEW_PARENT/data/proteins/raw_structures_hq_40k" \
  "$MIND_NEW_PARENT/data/proteins/afdb_clusters" \
  "$MIND_NEW_PARENT/data/rna/raw_structures" \
  "$MIND_NEW_PARENT/data/rna/manifests" \
  "$MIND_NEW_PARENT/data/rna_small" \
  "$MIND_NEW_PARENT/data/small_molecules/unimol" \
  "$MIND_NEW_PARENT/data/metabolites"
```

### 5.1. 1M küçük dosya

İlk aktarımda milyonlarca küçük dosyanın metadata maliyetini azaltmak için eski
sunucudan `tar` akışı kullanılabilir (bunu `tmux` oturumu içinde çalıştırın):

```bash
cd /media/ubuntu/8TB/yusuf/protein_data/raw_structures_1m_1024
tar -cf - . | ssh -C "${MIND_NEW_USER}@${MIND_NEW_HOST}" \
  "tar -xf - -C '${MIND_NEW_PARENT}/data/proteins/raw_structures_1m_1024'"
```

`tar` akışı kesilirse kaldığı yerden devam etmez. İlk aktarım tamamlandıktan sonra
veya kesilirse eksikleri güvenli biçimde tamamlamak için `rsync` ile uzlaştır:

```bash
rsync -aH --partial --info=progress2 \
  /media/ubuntu/8TB/yusuf/protein_data/raw_structures_1m_1024/ \
  "${MIND_NEW_USER}@${MIND_NEW_HOST}:${MIND_NEW_PARENT}/data/proteins/raw_structures_1m_1024/"
```

### 5.2. Diğer veri kümeleri

Eski sunucudan:

```bash
rsync -aH --partial --info=progress2 \
  /media/ubuntu/8TB/yusuf/protein_data/afdb_clusters/ \
  "${MIND_NEW_USER}@${MIND_NEW_HOST}:${MIND_NEW_PARENT}/data/proteins/afdb_clusters/"

rsync -aH --partial --info=progress2 \
  /home/yusuf/data/proteins/raw_structures_hq_40k/ \
  "${MIND_NEW_USER}@${MIND_NEW_HOST}:${MIND_NEW_PARENT}/data/proteins/raw_structures_hq_40k/"

rsync -aH --partial --info=progress2 \
  /home/yusuf/data/proteins/processed_14atom_chunk_* \
  /home/yusuf/data/proteins/processed_14atom_index_map.json \
  "${MIND_NEW_USER}@${MIND_NEW_HOST}:${MIND_NEW_PARENT}/data/proteins/"

rsync -aH --partial --info=progress2 \
  /media/ubuntu/8TB/arya/rna_data/ \
  "${MIND_NEW_USER}@${MIND_NEW_HOST}:${MIND_NEW_PARENT}/data/rna/raw_structures/"

rsync -aH --partial --info=progress2 \
  /media/ubuntu/8TB/yusuf/mind_virtual_v1/rna/final_23slot_chunk_* \
  /media/ubuntu/8TB/yusuf/mind_virtual_v1/rna/final_23slot_index_map.json \
  /media/ubuntu/8TB/yusuf/mind_virtual_v1/rna/final_23slot_validation.json \
  /media/ubuntu/8TB/yusuf/mind_virtual_v1/rna/final_23slot_reports \
  /media/ubuntu/8TB/yusuf/mind_virtual_v1/rna/manifests \
  "${MIND_NEW_USER}@${MIND_NEW_HOST}:${MIND_NEW_PARENT}/data/rna/"

rsync -aH --partial --info=progress2 \
  /media/ubuntu/8TB/yusuf/mind_virtual_v1/rna/june_equivalent_23slot_v2/ \
  "${MIND_NEW_USER}@${MIND_NEW_HOST}:${MIND_NEW_PARENT}/data/rna/june_equivalent_23slot_v2/"

rsync -aH --partial --info=progress2 \
  /home/yusuf/data/rna_small/ \
  "${MIND_NEW_USER}@${MIND_NEW_HOST}:${MIND_NEW_PARENT}/data/rna_small/"

rsync -aH --partial --info=progress2 \
  /media/ubuntu/8TB/arin/unimol_pyg_full/universal_unimol_chunk_* \
  "${MIND_NEW_USER}@${MIND_NEW_HOST}:${MIND_NEW_PARENT}/data/small_molecules/unimol/"
```

Metabolit verisi eğitimde kapalıdır; arşiv gerekmiyorsa taşınması zorunlu değildir.
Log ve `outputs/` dizinlerini ancak aktif yazma olmadığını doğruladıktan sonra aktar.

```bash
rsync -aH --partial --info=progress2 /home/yusuf/MIND/logs/ \
  "${MIND_NEW_USER}@${MIND_NEW_HOST}:${MIND_NEW_PARENT}/MIND/logs/"

rsync -aH --partial --info=progress2 /home/yusuf/MIND/outputs/ \
  "${MIND_NEW_USER}@${MIND_NEW_HOST}:${MIND_NEW_PARENT}/MIND/outputs/"
```

### 5.3. Aktarımı doğrula

Her iki sunucuda aynı kaynak/hedef için dosya sayısını ve toplam baytı karşılaştır:

```bash
find <KONTROL_EDILECEK_DIZIN> -type f -printf '%s\n' \
  | awk '{bytes += $1; files += 1} END {print files, bytes}'
```

Manifest ve checkpoint gibi kritik az sayıdaki dosya için ayrıca hash üret:

```bash
sha256sum <DOSYA>
```

## 6. Yeni sunucu yol ayarları

Mevcut 40k veriyle aynı eğitimi yeniden üretmek için çok-domain YAML'daki önekler
şunlar olmalıdır:

```yaml
multi_domain:
  datasets:
    pdb:
      chunk_dir: "../data/proteins/processed_14atom"
      chunk_range: [0, 9]
    unimol:
      chunk_dir: "../data/small_molecules/unimol/universal_unimol"
      chunk_range: [0, 9]
    rna:
      chunk_dir: "../data/rna/june_equivalent_23slot_v2/processed_23slot"
      chunk_range: null
    metabolite:
      enabled: false

dataset_download_dir: "../data/proteins/processed_14atom"
```

Fast config için RNA öneki:

```yaml
chunk_dir: "../data/rna_small/processed_23slot_5k"
```

1M veri işlendikten sonra protein öneki ayrı tutulmalıdır:

```yaml
chunk_dir: "../data/proteins/processed_14atom_1m"
chunk_range: [0, 99]
```

`Makefile` halen `/opt/anaconda3` veya eski makine yolları içeriyorsa yeni conda ve
veri köküne göre güncelle. Eğitim başlatmadan komut genişlemesini kontrol et:

```bash
make -n train CONFIG=f LOG=post_migration_smoke
```

Bağıl yollar repo kökünden çalıştırılacağı varsayımıyla yazılmıştır.

## 7. 1M proteini işle

Bu adım yalnızca şu dört koşuldan sonra yapılmalıdır:

1. Kullanılacak commit SHA ve geometry-neutral atom14/V runtime sözleşmesi
   kesinleşti.
2. Geometry-neutral, latent readout, balanced MLM ve FlashAttention scope testleri
   ile gerçek `.pt` sample smoke'u geçti.
3. Kullanıcı kontrollü kısa GPU eğitimi kabul metriklerini geçti.
4. Ham dosya sayısı, toplam bayt ve manifest hash'i iki sunucuda eşleşti.

Geometry-neutral çözüm mevcut 14/23-slot `.pt` dosyalarını yeniden üretmeyi
gerektirmez: görünür V ile masked sidechain/base slotları encoder'dan runtime'da
çıkarılır, eksik real-radius kenarları tamamlanır ve sabit slot çıktıları backbone
latent readout'undan üretilir. Yeni 1M veri yine atom14 cache olarak üretilir;
V'nin cache koordinatı fiziksel input kabul edilmez.

İşlenmiş 40k verinin üstüne yazmamak için farklı bir önek kullan:

```bash
python data_loading/process_chunked_dataset.py \
  --config-yaml-path core/pretraining_config_multidomain.yaml \
  --dataset pdb \
  --data-path ../data/proteins/raw_structures_1m_1024 \
  --manifest-file ../data/proteins/afdb_clusters/manifest_hq_1m_1024.csv \
  --output-base ../data/proteins/processed_14atom_1m \
  --cache-dir ../data/proteins/cache_14atom_1m \
  --num-chunks 100 \
  --use-hybrid-edges
```

Bu komut varsayılan olarak sıralı çalışır; `8 paralel grup` oluşturmaz. Paralel işlem
gerekiyorsa çakışmayan aralıklar kullanılmalıdır: `0-12`, `13-25`, `26-38`,
`39-51`, `52-64`, `65-77`, `78-89`, `90-99`. Her süreç ayrı loga yazmalı ve
komutun desteklediği chunk-range argümanları `--help` çıktısından doğrulanmalıdır.

`--force` varsayılan taşıma komutunda kullanılmaz; doğru hedefteki mevcut çıktıları
gereksiz yere ezme riski taşır.

İşleme tamamlandıktan sonra her `.pt` için metadata üret veya varlığını doğrula:

```bash
find ../data/proteins \
  -path '*/processed_14atom_1m_chunk_*/processed/*.pt' \
  -type f ! -name 'pre_*.pt' -print0 |
while IFS= read -r -d '' pt_file; do
  python data_loading/create_chunk_metadata.py --chunk-file "$pt_file"
done
```

Beklenen çıktı düzeni `processed_14atom_1m_chunk_0` ile
`processed_14atom_1m_chunk_99` arasında 100 kardeş chunk dizinidir. Üretilen veri ve
cache Git'e eklenmez.

## 8. Taşıma sonrası doğrulama

Önce kod ve küçük birim testleri:

```bash
git rev-parse HEAD
git status --short

MPLCONFIGDIR=/tmp/mind_mpl python -m pytest -q \
  tests/test_geometry_neutral_virtual_slots.py \
  tests/test_virtual_atom_stage3.py \
  tests/test_virtual_slot_diagnostics.py \
  tests/test_flash_varlen_attention_scope.py \
  tests/test_dynamic_sampler_epoch_plan.py \
  tests/test_dynamic_sampler_atom_quota.py \
  tests/test_filter_pyg_chunks_by_num_nodes.py \
  tests/test_rna_june_equivalent.py \
  tests/test_batch_statistics_callback.py \
  tests/test_lane_c_backend.py
```

Adapter ve veri sözleşmesi testleri:

```bash
pytest -v tests/test_adapters.py
```

Son olarak eğitim smoke testi kullanıcı tarafından Make hedefiyle başlatılır:

```bash
make train CONFIG=f LOG=post_migration_smoke
```

Başlatıldığı kullanıcı tarafından doğrulandıktan sonra Python worker PID'si, GPU PID,
output dizini ve ilgili logun iki gözlem arasında ilerlemesi birlikte izlenmelidir.
Smoke testte en az şu koşullar kontrol edilir:

- protein `N/CA/C/O` recall değerleri en az `0.90`, protein `V` en az `0.80`;
- RNA `C1'` recall en az `0.85`;
- toplam, MLM ve distance loss değerleri sonlu;
- protein, RNA ve UniMol batchleri gerçekten görülüyor.
- `masked_slot_short_distance` ve varsa `masked_slot_long_distance` sonlu;
- physical edge auditinde görünür V veya masked side/base endpoint sayısı `0`;
- `latent_slot_nodes` ve `slot_readout_links` sıfırdan büyük; owner linkleri ESA
  attention edge setine girmiyor;
- protein sidechain N/O/S ve RNA base element recall'ları sıfıra çakılmıyor;
- correct owner CE, shuffled/removed owner CE'den daha iyi yönde ayrışmaya başlıyor;
- ilk batch `GRADIENT AUDIT` satırında weighted MLM representation-gradient normu
  sonlu ve sıfırdan büyük;
- template-v1 kapalı, `geometry_neutral_virtual_slots` protein ve RNA için açık.

Smoke test geçmeden tam eğitim başlatılmaz. Tam eğitim de kullanıcı tarafından:

```bash
make train CONFIG=m LOG=multidomain_1m_production
```

## 9. Bilinen sınırlamalar

- Metabolit verisi `bond_edge_index` collate çakışması nedeniyle kapalı kalmalıdır.
- Lazy/dynamic batching ile `num_workers: 0` mevcut güvenli ayardır.
- Datasetler, cacheler, checkpointler ve W&B dosyaları Git'e eklenmemelidir.
- Yeni sunucunun W&B/API kimlik bilgileri ayrı ve güvenli biçimde kurulmalıdır.
- Taşıma tamamlanmış sayılmadan önce Git SHA, kritik hashler, dosya sayıları, ortam
  importları, birim testleri ve kullanıcı kontrollü smoke test birlikte geçmelidir.
