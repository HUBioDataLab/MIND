# MIND Data Locations

Bu dosya yalnızca kalıcı ham veri ve eğitime hazır PyG cache yollarını listeler.
Ara PKL/PT üretim dizinleri eğitim girdisi değildir.

| Domain | Ham veri | Seçim manifesti | Eğitime hazır PT base yolu | Temsil |
|---|---|---|---|---|
| Protein | `/home/yusuf/data/proteins/raw_structures_hq_40k/` | `/home/yusuf/data/proteins/afdb_clusters/manifest_hq_40k_len512.csv` | `/home/yusuf/data/proteins/processed_14atom` | 10 chunk, 40.000 protein, residue başına 4 backbone + 10 sidechain/V slotu |
| RNA | `/media/ubuntu/8TB/arya/rna_data/` | `/media/ubuntu/8TB/yusuf/mind_virtual_v1/rna/manifests/rna_final_23slot_manifest.csv` | `/home/yusuf/data/rna/processed_23slot` (8TB'deki final chunk'lara sembolik bağlantılar) | 67 chunk, 12.869 RNA; nucleotide başına 12 backbone + 11 base/V slotu; P-only ve mirror/L-RNA eğitim dışında |
| Small molecules | Eklenecek | Eklenecek | Eklenecek | UniMol cache bilgisi doğrulandıktan sonra doldurulacak |
| Metabolit | Eklenecek | Eklenecek | Eklenecek | Entegrasyon yeniden açıldığında doldurulacak |

## Loader kuralı

Config'e `_chunk_NNN` son eki olmayan base yol verilir. Örneğin
`/home/yusuf/data/rna/processed_23slot` verildiğinde loader kardeş
`processed_23slot_chunk_000`, `processed_23slot_chunk_001`, ... dizinlerini
otomatik bulur. Her chunk'ın `processed/` dizininde tek veri PT'si ve onunla
aynı stem'i taşıyan `_metadata.json` dosyası bulunmalıdır.

Protein index map:
`/home/yusuf/data/proteins/processed_14atom_index_map.json`.

RNA chunk bağlantıları gerçek 8TB yollarına çözüldüğü için loader index map'i
`/media/ubuntu/8TB/yusuf/mind_virtual_v1/rna/final_23slot_index_map.json`
yolunda tutar.

RNA'nın doğrulanmış fiziksel PT base yolu:
`/media/ubuntu/8TB/yusuf/mind_virtual_v1/rna/final_23slot`.

Final RNA bütünlük raporu:
`/media/ubuntu/8TB/yusuf/mind_virtual_v1/rna/final_23slot_validation.json`.
