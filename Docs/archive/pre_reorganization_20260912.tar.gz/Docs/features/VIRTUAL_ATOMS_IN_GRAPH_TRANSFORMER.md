# Graph Transformer'da Virtual Atom Karar Belgesi

## Belgenin amacı ve statüsü

Bu belge protein ve RNA'daki sabit slot/`V` temsilinin MIND graph transformer
içinde oluşturabileceği bütün bilinen bilgi sızıntısı, sahte geometri, graph,
masking, loss ve ölçüm sorunlarını tek yerde toplar. Amaç tek bir belirtiyi
düzeltirken başka bir kanaldan aynı hatayı yeniden üretmemektir.

**Statü (1 Eylül 2026; aşağıdaki eski önerilerin önüne geçer):** Geometry-neutral
fiziksel graph sözleşmesi mekanik olarak çalışıyor, fakat latent backbone readout
ile element-balanced loss birleşimi öğrenme kabulünü geçmedi. Üç ayrı 3-epoch
seed'de protein gerçek sidechain doğruluğu context-free slot prior'ında kaldı ve
doğru residue owner'ını başka residue owner'ıyla değiştirmek loss'u anlamlı
değiştirmedi. Bu nedenle "latent + element balance çözümdür" kararı geri
çekilmiştir. Sorunun V koordinatından daha geniş olduğu uçtan uca runtime audit
ile doğrulanmıştır. Bu belgede daha aşağıda duran sentetik template, query-node,
masked-slot distance ve element-balanced önerileri tarihsel deney kaydıdır;
güncel nihai öneri değildir.

## 1 Eylül 2026 uçtan uca eğitim pipeline audit'i

### Kesin sonuç

MIND şu anda V'nin sahte koordinatını fiziksel encoder graph'ından başarıyla
çıkarıyor. Buna rağmen model context kullanmıyor; slot numarasına göre en sık
elementi seçerek MLM'i ucuz biçimde çözüyor. Yani güncel başarısızlık:

```text
V sahte geometrisi encoder'a sızıyor                     HAYIR
Mask/target/metric yanlış node'a hizalanıyor            HAYIR
M katmanı hâlâ yanlışlıkla global çalışıyor             HAYIR
Model owner backbone bilgisini head'e ulaştıramıyor     HAYIR
Model ulaşan owner/context bilgisini kullanmayı öğreniyor HAYIR
```

Bu son satır üç seed'in ortak sonucudur. Owner context tamamen kaldırılınca
logitler çok değişiyor; başka residue'nun owner context'i verilince yaklaşık aynı
kalıyor. Dolayısıyla matematiksel yol ve gradient var, fakat farklı residue
context'leri tahmin için ayırt edici biçimde kullanılmıyor.

### Üç seed'in sonucu

| Seed | Protein real accuracy | Slot prior | Protein hetero recall | RNA real accuracy | RNA slot prior |
|---:|---:|---:|---:|---:|---:|
| 42 | 0.6001 | 0.6001 | 0.0000 | 0.5251 | 0.5848 |
| 43 | 0.6101 | 0.5937 | 0.0734 | 0.5092 | 0.6128 |
| 44 | 0.5991 | 0.5991 | 0.0000 | 0.5128 | 0.6110 |

Protein ortalama real accuracy `0.6031`, heteroatom recall `0.0245` oldu. Seed
42 ve 44, slot 1-3 için sürekli C; slot 4-10 için sürekli V üreterek slot
prior'ını birebir uyguladı. Seed 43'te element-balanced loss context öğrenmek
yerine slot 4'ün çoğuna S söyleyen başka bir sabit shortcut seçti.

Doğru owner ile shuffled owner arasındaki all-slot ortalama logit farkı yalnız
`0.048-0.060` (seed 42/43) ve `0.043` (seed 44) civarındaydı; owner tamamen
kaldırılınca fark `4.42-4.60` oldu. Bu, readout'un bağlı olduğunu ama residue
kimliğinin kullanılmadığını doğrudan gösterir.

### Gerçek runtime çağrı zinciri ve dosya bazında sonuç

| Sıra | Aktif dosya/fonksiyon | Eğitimde yaptığı iş | Audit sonucu |
|---:|---|---|---|
| 1 | `Makefile` -> `core.train_pretrain` | Config, seed, epoch ve output'u CLI'a verir | Doğru; seed 44 ilk komutta `python -mcore...` yazım hatasıyla değil, aynı GPU'daki başka process yüzünden OOM oldu; retry tamamlandı |
| 2 | `core/pretraining_config.py` | YAML'i dataclass'a çevirir ve geometry-neutral sözleşmeyi doğrular | Aktif ayarlar doğru okunuyor; çok sayıda tarihsel/dead config alanı ayrıca aşağıda listelendi |
| 3 | `core/train_pretrain.py::load_universal_dataset` | Aktif protein/RNA/UniMol chunk'larını seçer | Fast config yalnız chunk 0'ları kullanıyor; full config farklı RNA path'i ve natural full-pass kullanıyor |
| 4 | `data_loading/lazy_universal_dataset.py::__getitem__` | PT sample çıkarır, legacy atom id normalize eder, collate alanlarını tamamlar ve runtime template metadata ekler | Protein/RNA `pos_code`, block ve domain bilgisi korunuyor; target kayması bulunmadı |
| 5 | `core/train_pretrain.py::create_pretraining_data_transforms` | Dynamic Tier-3 transform'ü kurar; block MLM varsa per-sample atom maskesini kapatır | Block MLM seçimi doğru; Dynamic Tier-3 transform pratikte no-op, aşağıdaki P1 defect'e bak |
| 6 | `data_loading/improved_dynamic_sampler.py` | Metadata atom sayısıyla quota ve batch planlar | Fast quota, encoder'dan atılacak V/latent node'ları gerçek compute gibi sayıyor; protein efektif payını ciddi azaltıyor |
| 7 | `core/pretraining_model.py::_ensure_mlm_attributes` | Protein'de tam residue, RNA'da tam nucleotide seçer; `original_types` saklar ve seçilen atom id'lerini 0 yapar | Mask edilen block ve target'lar doğru; protein/RNA block sırası bozulmuyor |
| 8 | `core/pretraining_model.py::_ensure_masked_slot_template` | Eski sentetik template fonksiyonunu her step çağırır | Config kapalı olduğu için no-op; güncel graph'a etki etmiyor ama aktif akışta gereksiz tarihsel çağrı |
| 9 | `core/virtual_slot_graph.py::build_geometry_neutral_graph_view` | Görünür V'leri ve masked side/base target slotlarını ESA graph'ından çıkarır; real-only radius edge'leri tamamlar | V/target endpoint'li fiziksel edge kalmıyor; graph kopması veya cross-graph edge bulunmadı |
| 10 | `core/molecular_encoder.py` | Atom/period/slot embedding ve invariant graph özetleri üretir | Slot id type-independent ve doğru; fakat `chemical_coordination` ve RBF tüm edge tier'lerini kimyasal/geometrik komşu gibi topluyor |
| 11 | `esa/masked_layers.py` + `esa/mha_flash_varlen.py` | M katmanları sparse graph-local, S katmanları molecule-global attention yapar | M/S ayrımı güncel kodda doğru; önceki adjacency fallback hatası bu çalışmanın nedeni değil |
| 12 | `core/pretraining_model.py::_inject_latent_slot_readouts` | Target state'i owner backbone hidden-state ortalaması + slot embedding olarak üretir | Her target doğru owner'a bağlı ve differentiable; owner mean'lerin residue'lar arasında ayırt ediciliği çok düşük |
| 13 | `core/pretraining_tasks.py` | Regular short/long distance, masked-slot short/long distance ve tek 121-sınıf MLM loss hesaplar | Asıl optimizasyon shortcut'ı burada: iki ekstra masked-slot distance görevi baskın; element macro context kullanımını zorunlu kılmıyor |
| 14 | protein/RNA metric callback'leri | Aynı validation forward'ının MLM argmax'ını, yalnız ilgili domain ve masked node'larda ölçer | 0.599 metric artefaktı değil; slot-majority baseline'ın gerçek matematiksel sonucu |
| 15 | `core/metrics/virtual_slot_diagnostics_callback.py` | Slot prior ve owner removed/shuffled counterfactual ölçer | Test doğru şeyi ölçüyor ve üç seed'de context kullanılmadığını gösteriyor |

Protein ve RNA adapter'ları ile `data_loading/cache_to_pyg.py` eğitim sırasında
çağrılmaz; onlar offline PT üretim yoludur. Mevcut PT'ler bu audit'te read-only
incelendi.

### Veride ve graph routing'de doğrulanan sağlam noktalar

- İlk 500 protein graph'ındaki 78,926 residue block'unda 14-slot canonical sıra
  hatası bulunmadı.
- Mevcut 147 RNA graph'ının 11,031 nucleotide block'unda 23-slot canonical sıra
  hatası bulunmadı.
- Bir gerçek mixed batch audit'inde 3,419 raw node'un 788 görünür V'si ve 301
  masked side/base target'ı encoder'dan çıkarıldı; 2,330 fiziksel node kaldı.
- Masked protein target'ları `C/N/O/S/V`, RNA target'ları `C/N/O/V` olarak
  doğru `original_types` üzerinde kaldı.
- Fiziksel edge'ler symmetric, graph-local ve geometry-valid idi; aktif izole
  node bulunmadı.
- Protein masked backbone anchor'larının ortalama degree'si `25.2`, masked
  block dışı ortalama komşu sayısı `22.2` idi. RNA ortalama degree `16.7` idi;
  local komşusu olmayan birkaç RNA anchor'ı S katmanında molecule-global
  context görmeye devam ediyor.
- Focused test paketi: `61 passed`. Bu testler mekanik sözleşmeyi kanıtlar;
  öğrenme başarısını kanıtlamaz.

### Doğrulanmış defect ve öğrenme engelleri

| Öncelik | Sorun | Kanıt | V öğrenmesine etkisi |
|---|---|---|---|
| P0 | Masked gerçek side/base koordinatları için ek short + long distance loss'ları toplam optimizasyonu domine ediyor | Seed audit'lerinde bu iki görev shared-state gradient normlarının yaklaşık `%65-%75`'ini taşıdı; bütün distance görevleri birlikte yaklaşık `%88-%90` | Slot embedding'den tipik slot mesafesi tahmin edilebilir. Model residue context'i öğrenmeden toplam loss'u hızlı düşürür. Bu iki görev diğer grubun tek MLM loss yapısının kopyası değildir |
| P0 | `element_balance_weight=0.5` context kullanımını zorlamıyor | Macro CE, batch'te bulunan elementleri tek protein/RNA side/base grubu içinde eşitler; slot başına veya residue context'ine göre koşullamaz. Seed 43 S sabitine kaçtı | Bir shortcut'ı kapatmak yerine başka bir slot sabitini ucuz hale getirir; nadir element batch'te yoksa sinyal de yoktur |
| P0 | MLM domain başına normalize edilmiyor | Tek `real_loss` içindeki protein/RNA/UniMol katkısı masked real atom sayısına bağlı; V mean sonradan `0.2` ile ekleniyor | Protein sidechain sinyali batch kompozisyonu ve graph büyüklüğü tarafından seyreltilir. Full natural-pass config için de açık domain loss ağırlığı yoktur |
| P1 | Fast sampler raw PT node sayısını bütçeliyor | Fast epoch 0: raw paylar protein/RNA/UniMol `%30.0/%25.1/%45.0`; encoder-active paylar yaklaşık `%18.8/%26.6/%54.7`. Protein raw node retention yalnız `0.514` | Üç epoch'ta model sandığımızdan çok daha az protein fiziksel context ve gerçek sidechain target görür. Logdaki atom oranı da gerçeği olduğundan iyi gösterir |
| P1 | Dynamic Tier-3 edge transform hiç çalışmıyor | Transform `position_indices` arıyor; production PT kontratı `pos_code` kullanıyor. Gerçek sample'da transform öncesi/sonrası 61,471 edge bitwise aynı. Hata `677f22f` commit'inden beri var | Protein her epoch farklı long-range context görmüyor; cached statik Tier-3'e bağlı kalıyor. Tek başına V shortcut'ını açıklamaz ama context çeşitliliğini azaltır |
| P1 | Edge tier/mesafe semantiği attention'a ulaşmıyor | Node-attention yolu `edge_attr` kullanmıyor. M yalnız binary `edge_index` görüyor; Tier-1, Tier-2 ve Tier-3 aynı ilişki. S global attention'da pairwise distance bias kapalı | Model yakın fiziksel komşu, sequence komşusu ve rastgele uzak node'u attention skorunda doğrudan ayıramaz. Diğer grubun her atom için açık x/y/z tokenları görmesinden temel fark budur |
| P1 | `chemical_coordination` gerçek kimyasal bağ sayısı değil | `core/molecular_encoder.py` bütün `edge_index` edge'lerini sayıyor; CA sequence ve random Tier-3 dahil. Aynı tüm-edge kümesi RBF toplamına da giriyor | Uzak/rastgele bağlantılar backbone invariant temsilini "kimyasal koordinasyon" gibi kirletir. Bu V leakage değildir ama owner context'ini birbirine benzetir |
| P2 | Protein/RNA için gerçek covalent bond/bond-order graph encoder'da yok | PT converter `bond_edge_index` üretebilir ama protein/RNA'da boş; node encoder/M attention bunu kullanmıyor | Model bağ ile yakın teması aynı binary edge olarak görür. Atom tipi ön-eğitimi için hayati bir bağlam zayıflığıdır; fakat mevcut 0.599'un tek nedeni diye ispatlanamaz |
| P2 | Latent owner context eşit ortalamayla sıkıştırılıyor | N/CA/C/O veya 12 RNA backbone hidden state'i role-aware projection olmadan mean edilir | Rol ve yön bilgisi kısmen silinebilir. Fakat objective/sampling düzelmeden yeni readout eklemek yine shortcut'ı çözmez; bu nedenle ilk değişiklik olmamalıdır |
| P2 | Üç epoch yalnız 420 optimizer step | Diğer grubun repo config'leri çoğunlukla 100k-1M step; ayrıca explicit atom+x+y+z token loss'u ve source weight kullanıyor | Fast run yalnız wiring/smoke için yeterli. Öğrenme kabulü için yeterli değil; buna rağmen iki seed'in tam prior'a çökmesi objective kusurunu göstermek için yeterlidir |

### Diğer grupla gerçek fark

`repomix-output.xml` kodunda diğer grup `residue_padded_all` ile sabit 14/23
çıktıyı koruyor. Tek objective içinde:

```text
loss_real    = mean(real atom CE) + axis_weight * mean(real x/y/z loss)
loss_virtual = V/virtual-block loss
loss         = loss_real + 0.2 * loss_virtual
```

Protein/RNA/UniMol/Coconut kaynaklarının örnek config'inde kaynak ağırlıkları
eşit `0.25`; maskeli atomların yanında coordinate tokenları da doğrudan hedef.
ModernBERT global attention ve sequence position bilgisini görür. MIND ise aynı
deneyde regular short/long'a ek iki masked-slot distance görevi çalıştırıyor,
domain-normalized MLM kullanmıyor, edge türünü attention'a vermiyor ve yalnız
420 step eğitiliyor.

Bu kod farkları diğer grubun neden daha rahat öğrenebileceğini açıklar. Ancak
yalnız repo kodundan onların modelinin owner/context kullandığı yüzde yüz
kanıtlanamaz; bunun için aynı slot-prior ve owner-shuffle kabul testi veya kayıtlı
model sonuçları gerekir.

### Neden önceki çözümler problemi bitirmedi?

1. Sentetik V koordinatını taşımak yalnız geometry shortcut'ını değiştirdi.
2. Query node ve sonra latent readout owner'a bir bilgi yolu açtı; fakat loss bu
   yolu kullanmayı gerektirmedi.
3. M katmanını sparse/local düzeltmek routing hatasını kapattı; model yine slot
   prior'ıyla daha ucuz loss buldu.
4. Element macro nadir atomlara ağırlık verdi ama "hangi residue?" sorusunu
   sormadı; bu yüzden context yerine S/O gibi yeni sabit tahminler oluştu.
5. Ek masked-distance görevleri, slot id'den ortalama koordinasyon mesafesi
   öğrenerek çok büyük gradient aldı.
6. Fast sampler protein V'lerini compute zannedip protein encoder işini yaklaşık
   `%30` değil `%19` verdi. Böylece çözmek istediğimiz domain en az beslendi.

Yani denemeler tamamen anlamsız değildi: V geometry leakage, M routing ve metric
artefaktı ihtimallerini elediler. Hata, bu mekanik düzeltmeleri öğrenme teşviki
zannetmemizdi.

### Güncel en sade çözüm kararı

Yeni bir V koordinatı, occupancy head, iki aşamalı MLM veya residue classifier
eklenmemelidir. Önce mevcut tek MLM head ile diğer grubun kanıtlanmış objective
ayrımına yaklaşılmalıdır:

```text
Her domain d için:
    L_d = mean CE(real masked atomlar_d)
          + 0.2 * mean CE(V targets_d)

Toplam MLM = sabit domain ağırlıklarıyla L_protein + L_RNA + L_UniMol
```

Bu hâlâ aynı 121-sınıf head'dir; yeni tahmin görevi değildir. Protein real grubu
backbone ve gerçek sidechain atomlarını, RNA real grubu backbone ve gerçek base
atomlarını içerir. V çıktı sözleşmesinde kalır fakat protein/RNA gerçek atom
gradient'ini batch büyüklüğüyle boğamaz.

Aynı düzeltme paketinde yapılması gereken kanıtlanmış temizlikler:

1. Geometry-neutral graph view korunur; V fiziksel encoder'a geri konmaz.
2. `masked_real_distance_weight` ve `element_balance_weight` sıfırlanır. Regular
   physical short/long distance görevleri korunur.
3. MLM domain başına real/V normalize edilir; açık domain ağırlıkları kullanılır.
4. Fast sampler ve batch telemetry raw slot node yerine encoder-active/effective
   node sayısını hesaba katar. PT yeniden üretmek gerekmez; metadata sidecar veya
   runtime template sayılarından türetilebilir.
5. Dynamic Tier-3 `pos_code`/template anchor kontratına göre düzeltilir ve gerçekten
   epochlar arasında değiştiği test edilir.
6. Random/long edge'ler `chemical_coordination` ve local RBF chemistry toplamından
   çıkarılır. Tier-3 yalnız attention routing edge'i olur.

İlk doğrulamada latent mean readout veya ESA katmanları yeniden değiştirilmemelidir.
Bu temiz objective ile yeterli optimizer step sonrasında model hâlâ slot prior'ında
ve owner-shuffle etkisi sıfırsa, bir sonraki ve tek mimari aday role-aware backbone
readout + edge-type/distance-aware M attention'dır. O noktada sorun V değil, ESA'nın
pairwise yapısal bağlam kapasitesidir.

### Kabul kriteri

Bir run'ın loss düşürmesi veya V recall yükseltmesi başarı sayılmaz. V problemi
yalnız şu üç koşul birlikte görülürse çözülmüş sayılır:

1. Protein ve RNA gerçek side/base doğruluğu kendi slot prior'ını birden fazla
   seed'de tutarlı biçimde aşar; protein heteroatom recall sıfıra çökmez.
2. Correct owner yerine shuffled owner verildiğinde real CE artar ve accuracy
   düşer. Owner'ı tamamen kaldırma testi tek başına yeterli değildir.
3. Regular distance, UniMol, backbone ve V metriklerinde belirgin regresyon
   oluşmaz.

Üç epoch/420-step fast çalışma yalnız crash, NaN, routing ve kaba regresyon
smoke testidir. Bu kabul için ardından birkaç bin optimizer step'lik protein/RNA
öğrenme koşusu gerekir.

## Eskimiş, inactive veya yanıltıcı kod envanteri

| Kod/config | Durum | Risk |
|---|---|---|
| `core/masked_coordinate_corruption.py` ve `core/virtual_atom_templates.py` | Sentetik template config kapalı; train/val/test'te fonksiyon yine çağrılıp hemen dönüyor | Güncel çözüm sanılabiliyor; yaklaşık yüzlerce satır tarihsel kod aktif çağrı zincirini gereksiz karmaşıklaştırıyor |
| `MaskBondTypes`, `AddDistanceFeatures`, `AddAngleFeatures`, `AddGraphProperties`, `CreateMaskedPairs`, `MultiTaskTransform`, `RandomAugmentation`, `DomainSpecificTransform` | Yalnız `data_loading/pretraining_transforms.py` içinde tanımlı, başka Python dosyasında referansı yok | Dead API yüzeyi; hangi transform'ün aktif olduğunu gizliyor |
| `coordinate_denoising_head` | Task kapalı olsa da her modelde instantiate ediliyor | Kullanılmayan parametre/checkpoint yükü; V öğrenmesini etkilemiyor |
| `distance_prediction_weight`, `mlm_weight`, `temperature`, `num_sabs`, `triu_attn_mask` ve YAML'deki hierarchical/PE alanlarının çoğu | Güncel pretraining path'inde objective/forward'a bağlı değil veya açıkça `Not used` | Config değişti sanılıp eğitim aynı kalabilir |
| `get_adj_mask_from_edge_index_node` dense maskesi | Flash-varlen M sparse edge, S global kullanmasına rağmen her forward'da `[B,N,N]` mask oluşturuluyor; default device `cuda:0` | Gereksiz VRAM/zaman; büyük mixed batch OOM riskini artırır, öğrenme semantiğini değiştirmez |
| `PMAFlashVarlen` | Verilen `seq_lens`i kullanmadan padding maskesiz padded fallback yapıyor | Node MLM loss pre-PMA olduğu için mevcut V sonucunun nedeni değil; graph-level embedding/downstream için ciddi padding bağımlılığı riski |
| `_compute_per_type_losses` | Logging için short/long loss'u yeniden stochastic hesaplıyor; dominant masked-slot distance loss'larını rapora katmıyor | RNG ilerletir, ek autograd/hesap maliyeti yaratır ve domain total loglarını eksik gösterir |
| `BatchStatisticsCallback` ve model içi batch ratio logları | Raw PT node sayısını raporluyor | Encoder'dan atılan V/latent node'lar yüzünden özellikle protein payını yanlış gösterir |
| Training YAML'deki hybrid-edge ayarları | Mevcut PT'yi baştan üretmez; yalnız bazı runtime yollar bunları okur | Config yorumları "her epoch yeniden üretiliyor" izlenimi verirken dynamic transform no-op kalabilir |

## Tarihsel 31 Ağustos tasarım kaydı

> Bu bölümden belgenin sonuna kadar olan öneri ve tablolar, hangi hipotezlerin
> denendiğini kaybetmemek için korunmuştur. Özellikle masked-real distance ve
> element-balanced loss maddeleri 1 Eylül GPU sonuçlarıyla reddedilmiştir. Yeni
> uygulama kararı yukarıdaki **Güncel en sade çözüm kararı** bölümüdür.

### O tarihteki kısa karar

Sabit slotlardan vazgeçilmemelidir:

- protein her residue için `4 backbone + 10 sidechain slotu`,
- RNA her nucleotide için `12 backbone + 11 base slotu`

korumalıdır. Böylece maskelenen bir block'un gerçek atom sayısı node sayısından
okunamaz.

Ancak `V`, fiziksel bir atom değildir. Bu nedenle önerilen temel ayrım şudur:

1. `V`, vocabulary ve MLM hedefinde gerçek bir **padding sınıfı** olarak kalır.
   Maskelenmemiş görünür V encoder'a girmez. Maskeli block'un side/base slotları
   da ESA node'u olmaz; yalnız encoder sonrası latent çıktı slotlarıdır.
2. `V`, fiziksel geometri kanalında atom sayılmaz: spatial edge, distance/RBF,
   equivariant edge vector, graph merkezi veya fiziksel distance target üretmez.
3. Seçilen masked block'taki bütün sidechain/base slotları, hedefi gerçek veya
   `V` olmasına bakılmadan aynı şekilde geometriden saklanır.
4. Slot hedefleri silinmez. Her latent slot, kendi residue/nucleotide backbone
   atomlarının ESA çıktılarının ortalaması ile type-independent canonical slot
   embedding'inin toplamından üretilir. Tek MLM head element veya `V=120`
   tahmin eder.
5. Gerçek masked slotların temiz koordinatları yalnız supervision tarafında,
   mevcut distance head'lerine hedef üretmek için kullanılabilir. `V` slotuna
   distance target verilmez.

Bu tasarımın ana ilkesi:

> Sabit slot çıktı sözleşmesidir; ESA yalnız fiziksel yapıyı görür. Gerçek
> koordinat ve gerçek/V doluluğu masked block için yalnız hedeftir.

## Üç sistem gerçekte ne yapıyor?

| Kanal | Diğer grup (`repomix-output.xml`) | BoltzGen | Mevcut MIND template-v1 |
|---|---|---|---|
| Model | BERT/ModernBERT token MLM | All-atom coordinate diffusion | ESA graph/set transformer + atom MLM + distance losses |
| Protein boyutu | 14 atom, her atom `[element,x,y,z]` token bloğu | Tasarlanan residue için atom14 | 14 graph node |
| RNA boyutu | 23 atom | Protein marker sistemine denk RNA decoder'ı yok | 23 graph node |
| V/fake input semantiği | Açık residue'da `V` ve koordinat tokenları görünür | Generic `V=120` sınıfı yok; protein fake marker'ları coordinate target | Generic `V=120` node |
| Maskelenen block | Element ile x/y/z tokenlarının tamamı `[MASK]` | Atom özellikleri maskeli, koordinatlar diffusion ile gürültülü | Atom tipi maskeli; 10/11 side/base slotu sentetik input noktalarına taşınır |
| Spatial graph | Yok | Diffusion/atom attention; MIND radius graph'ı değil | Radius/hybrid graph, geometric node features ve equivariant branch var |
| V placement | Protein: özel N/CA/C döngüsü. RNA: P/C4' ve N9/N1 | Protein fake marker target'ları N veya O üzerinde | Masked side/base slotlarının tamamı type-independent sentetik bulutta |
| Çıktı | Element ve coordinate tokenları | Koordinatlar; N/O marker sayısından residue decode | Tek 121-sınıf element MLM; `120=V` |
| Önemli sonuç | Anchor koordinatı masked block'ta input graph'ı bozamıyor; çünkü graph yok ve koordinat tokenı gizli | Marker geometrisi temiz input cevabı değil, üretilen hedeftir | Sentetik geometri doğrudan encoder input'u ve edge kaynağıdır |

Diğer grubun protein N/CA/C ve RNA P/C4'/N9-N1 kuralları, kodda
"BoltzGen Style" diye adlandırılsa da BoltzGen'in gerçek N/O marker tablosunun
kopyası değildir; grubun kendi residue-specific uyarlamasıdır. Ayrıca N9/N1 RNA
base atomlarıdır, backbone değildir.

## MIND'da node rolleri

Önerilen çözüm tek bir `is_virtual` maskesiyle kurulamaz. En az üç farklı rol
ayrılmalıdır:

| Rol | Örnek | Atom/token kanalı | Fiziksel geometri kanalı | MLM hedefi | Distance hedefi |
|---|---|---|---|---|---|
| Görünür gerçek atom | Açık residue'daki CB/OG veya RNA base atomu | Gerçek element görünür | Gerçek koordinat ve gerçek edge | Yok | Mevcut görevler |
| Görünür V padding | Açık ALA'nın boş sidechain slotları | Raw sabit slotta ve label vocabulary'sinde bulunur; encoder attention'ında inactive | **Tamamen kapalı** | Yok | Yok |
| Masked side/base slotu | Seçilen block'taki `s1..s10` / `b1..b11`; target real veya V olabilir | Hepsi aynı mask tokenı + type-independent slot id | **Tamamen kapalı** | Element veya V | Yalnız target gerçekse temiz distance |
| Masked backbone atomu | Seçilen proteindeki N/CA/C/O | Element maskeli, backbone slot id sabit | Gerçek backbone koordinatı korunur | Mevcut MLM | Mevcut distance |
| Diğer domain gerçek atomu | UniMol atomu | Mevcut davranış | Mevcut davranış | Mevcut atom-MLM | Mevcut distance |

Burada "fiziksel geometri kapalı" yalnız `edge_index`ten edge silmek değildir.
Aşağıdaki bütün kanalların aynı `geometry_valid_mask` sözleşmesini kullanması
gerekir.

Önerilen maske:

```text
geometry_valid = visible_real_atom OR retained_masked_backbone

visible_V                    -> false
masked_protein_side_slot     -> false  (target real/V fark etmez)
masked_RNA_base_slot         -> false  (target real/V fark etmez)
```

Masked block'ta target gerçek/V ayrımına göre maske değiştirilmemelidir. Aksi
halde occupancy bilgisi başka bir kanaldan tekrar input'a sızar.

## Uçtan uca risk ve çözüm tablosu

`Kaynak` sütunundaki anlam:

- **DG:** diğer grubun kodunda bulunan davranış.
- **BG:** BoltzGen'de bulunan davranış.
- **MIND:** zaten mevcut olan davranış/head.
- **YENİ:** graph nedeniyle MIND'da gerekli, iki referanstan aynen alınmamış uyarlama.

| # | Katman / sorun | Diğer grup neden yaşamıyor veya nasıl yönetiyor? | MIND'daki arıza | Önerilen tek çözüm | Kaynak | Kabul testi |
|---:|---|---|---|---|---|---|
| 1 | Atom sayısından residue kopyası | Masked protein 14, RNA 23 slotun tamamını taşır ve tamamını maskeler | Gerçek atomları bırakıp V'yi çıktıdan silersek tahmin sayısı residue/nucleotide türünü açıklar | Sabit 14/23 **çıktı** sözleşmesini koru; 10/11 latent slotu target türünden bağımsız üret | DG ilkesi + YENİ readout | Bütün canonical block'lar exact 14/23; latent slot sayısı target türünden bağımsız |
| 2 | V koordinatının doluluğu açıklaması | Masked block'un x/y/z tokenları da maskelidir | Gerçek atom true coordinate, V backbone/başka noktadaysa model real/V ayrımını koordinattan okur | Masked side/base slotlarında target real/V fark etmeksizin koordinat-derived bütün inputları kapat | DG ilkesi + YENİ graph maskesi | Aynı backbone/context altında target etiketleri değiştirilince forward input tensorları bitwise aynı |
| 3 | Anchor üzerinde sıfır mesafe yığını | Koordinat tokenı graph edge üretmez | CB/C1'/N/CA/C/O üzerine V koymak sıfır mesafe, V shortcut'u ve anchor recall çöküşü üretir | V hiçbir spatial graph'a girmesin; anchor yalnız gerçek backbone node olarak kalsın | YENİ; BG marker placement **input olarak kopyalanmıyor** | V içeren bütün forward spatial edge mesafeleri `>0`; hiçbir edge endpoint'i visible V değil |
| 4 | Sentetik template'in sahte kimyası | Böyle bir spatial template yok | Ayrı q noktaları zero-distance sorununu çözerken sahte bağ/komşuluk/mesafe öğretir | `masked_slot_template` noktalarını fiziksel input olarak kullanma; masked slot geometri kanalı sıfır olsun | YENİ | Placeholder koordinatları rastgele değiştirildiğinde logits/loss değişmemeli |
| 5 | Radius `max_neighbors` kotasının V tarafından doldurulması | Radius graph yok | Cache oluşturulurken yığılmış V'ler komşu kotasını tüketir; sonradan V edge silmek elenmiş real-real edge'leri geri getirmez | Forward için spatial edge'leri `geometry_valid_mask` üzerindeki gerçek koordinatlardan yeniden kur; cache spatial edge'ini doğru varsayma | YENİ | Runtime real-real edge seti doğrudan real-only radius graph referansıyla aynı |
| 6 | Hybrid graph Tier 1/2/3 ayrımı | Yok | Protein Tier 2 V'den etkilenir; Tier 1 ve Tier 3 yalnız CA olduğu için farklı semantik taşır | Tier 1 CA sequence ve Tier 3 CA random edge'lerini koru; yalnız Tier 2 spatial kısmını real-only yeniden kur ve duplicate filtresini tekrar uygula | Mevcut MIND + YENİ rebuild | Her tier ayrı sayılır; V endpoint `0`; Tier 1/3 referansla aynı |
| 7 | RNA graph'ı | Graph yok | RNA cache'i ağırlıkla radius graph; C1' stacking deneyi 868,574 zero-distance edge üretmişti | RNA spatial graph'ını da proteinle aynı real-only `geometry_valid_mask` ile runtime kur | YENİ | RNA V endpoint `0`; C1' derece/recall kontrolü; protein ve RNA aynı kontratı kullanır |
| 8 | Node geometric features | x/y/z yalnız token | MIND coordination, close/medium counts, min/mean distance ve Gaussian RBF'yi edge/pos'tan toplar; yalnız edge_attr silmek yetmez | Encoder bütün geometrik aggregate'leri yalnız geometry-valid edge/node'lardan hesaplasın; invalid node'un projected geometry çıktısı bias dahil tam sıfır olsun | YENİ | Invalid node geometric embedding normu tam `0`; visible real node değerleri real-only referansla aynı |
| 9 | Equivariant branch | Yok | NequIP branch `edge_vectors=pos[dst]-pos[src]` kullanır; V veya placeholder edge'i doğrudan mesaj olur | Invalid node'a temas eden edge equivariant branch'e girmesin; masked side/base slotu yalnız invariant attention'dan context okusun | YENİ | Equivariant edge endpoint'lerinde `geometry_valid=true`; placeholder perturbasyonuna invariant çıktı |
| 10 | Invariant attention | Bütün non-PAD V ve mask tokenları normal attention tokenıdır | V spatial edge üretmese bile attention softmax'ını seyreltir; önceki masked query node'ları da owner context'i kullanmadan slot prior ezberledi | Görünür V ve maskeli side/base slotlarını encoder token setinden çıkar; slotları yalnız backbone latent readout olarak üret | YENİ; query-node deneyi başarısız | ESA Q/K/V setinde visible V ve masked side/base slotu yok; correct/removed/shuffled readout audit'i raporlanır |
| 11 | Flash-varlen attention maskesi | ModernBERT kendi attention maskesini kullanır | Attention scope/kernel davranışına owner routing doğruluğu bağlanırsa backend değişimi semantiği bozabilir | Owner linklerini attention edge'i olarak kullanma. ESA yalnız fiziksel compact graph'ı işler; slot->backbone linki post-ESA salt readout ilişkisidir | YENİ | ESA attention edge seti fiziksel edge setine eşit; readout linkleri attention'a girmiyor |
| 12 | Graph merkezleme / COM | Coordinate tokenları doğrudan graph merkezlemez | Forward bütün node koordinatlarının ortalamasını alıyor; V/placeholder tüm gerçek koordinatları kaydırır | Merkezi yalnız geometry-valid node'lardan hesapla. Seçilen block'taki 10/11 slotun tamamını, gerçek/V ayrımı yapmadan merkez hesabından çıkar | YENİ | Placeholder/V koordinat perturbasyonu centered real positions'ı değiştirmemeli |
| 13 | Distance attention bias | Graph distance bias yok | Açılırsa bütün pairwise `pos` değerlerinden bias üretir; edge silmek bunu engellemez | Bias yalnız iki endpoint de geometry-valid olduğunda kullanılmalı; invalid pair bias'ı nötr/kapalı olmalı. Özellik kapalıyken de regresyon testi bulunmalı | YENİ | Bias matrisinde invalid pair yok/nötr; placeholder perturb invariant |
| 14 | Laplacian/RWSE graph PE | BERT positional embedding kullanır | Gelecekte cache graph'ından PE açılırsa V topology'si yeniden sızar | Şimdilik `use_posenc=false`; açılacaksa PE real-only runtime graph'tan hesaplanmadan kullanım yasak | YENİ güvenlik kuralı | Config guard ve PE graph V-endpoint testi |
| 15 | Slot embedding shortcut'u | Atom/X/Y/Z slot ve atom-position embedding kullanır | MIND domain-local slot id type-independent olsa da slot marginals güçlüdür: son slotlar çoğunlukla V, ilk slotlar çoğunlukla real | Slot id korunur; aksi halde hangi output slotunun tahmin edildiği bilinmez. Ancak slot-only ve context-shuffled baseline zorunlu olur; başarı yalnız overall MLM ile iddia edilmez | DG + mevcut MIND | Per-slot majority baseline, context-shuffle delta ve per-residue exact metrikleri |
| 16 | V'nin graph pooling'i bozması | Sequence modelinde ayrıca MIND PMA graph embedding'i yok | Çok sayıda görünür V veya query node PMA/mean pooling'i seyreltebilir | İkisi de ESA öncesi compact edildiği için pooling'e ulaşmaz; latent slotlar graph embedding hesaplandıktan sonra oluşturulur | YENİ downstream kuralı | Visible V/masked slot placeholder'ı graph embedding'i değiştirmemeli |
| 17 | Masked slot context'e nasıl ulaşacak? | Full self-attention ile sequence context'ini görür | Query-node sürümünde owner yolu vardı ama üç seed'de owner shuffle duyarlılığı yaklaşık sıfır kaldı | ESA fiziksel grafı işler; slot state=`LayerNorm(mean(owner backbone states)+slot embedding)`. MLM/distance gradienti bu eşitlik üzerinden owner backbone'a zorunlu gider | YENİ latent readout | Latent slot loss'undan yalnız kendi owner backbone'una nonzero gradient; shuffled/removed gerçek eğitim CE'sini bozmalı |
| 18 | Gerçek sidechain/base geometrisinin kaybı | Atomla beraber coordinate tokenlarını da geri tahmin eder | Template-v1 gerçek koordinatı inputtan siliyor ama hiçbir target vermiyor; SCr/BaseR düşük kalabiliyor | Temiz koordinatı input graph'a geri verme. Yalnız gerçek masked slotlar için temiz pair-distance target üret ve mevcut distance head'ine ver | DG coordinate target ilkesi + mevcut MIND head + YENİ pair routing | Masked-real distance bin accuracy/MAE; V pair sayısı `0`; target pair'ler forward graph'ında kullanılmıyor |
| 19 | Distance supervision'ın input'a sızması | Label tokenları model input'undan ayrı | Clean neighbor list forward `edge_index`e yanlışlıkla eklenirse cevap yeniden görünür | `input_edge_index` ve `target_pair_index` ayrı alanlar olsun; target pair yalnız forward bittikten sonra loss'ta okunsun | YENİ | Target pair/clean_pos permütasyonu forward logits'i değiştirmemeli; yalnız loss değişmeli |
| 20 | V için anlamsız distance loss | Virtual coordinate tokenlarını ayrıca reconstruct eder; bu onların kendi temsil hedefidir | MIND V fiziksel atom değilken anchor/synthetic koordinatını target yapmak sahte kimyayı kalıcılaştırır | V target'larda bütün physical distance/coordinate loss kapalı; yalnız MLM `V` loss'u var | YENİ MIND semantiği | V slotlarından distance gradient ve target pair sayısı `0` |
| 21 | Short-range ve long-range loss'un mevcut davranışı | Tek token MLM loss'u içinde coordinate token loss'u var | MIND template node'larını her iki distance loss'tan tamamen çıkarıyor; masked gerçek sidechain geometri öğrenmiyor | Mevcut visible-real distance görevlerini koru; masked-real slotu aynı block'taki 4/12 backbone atomuna bağlayan temiz target pair'leri mesafesine göre mevcut short/long head'e yönlendir | Mevcut MIND + YENİ supervision seti | Eski visible-real loss korunur; yeni loss yalnız masked-real slotlarda nonzero |
| 22 | Distance target sayısının büyük residue'leri kayırması | Real/virtual loss gruplarını ayrı ortalar | TRP/A/G gibi çok real slotlu block daha fazla pair üretir ve gradienti domine eder | Distance loss önce slot başına, sonra block başına normalize edilmeli; V block'a sıfır fiziksel loss | YENİ | GLY/ALA/TRP ve A/C/G/U block başına toplam effective weight raporu eşit |
| 23 | MLM V sınıf dengesizliği | Real ve virtual loss'u ayırıp virtual weight uygular | Node sayısı çok olduğu için ham CE V'ye çöker; aşırı düşük V weight ise V öğrenilmez | Tek 121-class head korunur; mevcut `real_loss + w*virtual_loss` başlangıç sözleşmesi korunur. `w` yalnız V recall ile değil real-side/base ve exact-block metrikleriyle seçilir | DG + mevcut MIND | V recall, real recall, SCr/BaseR, exact block ve confusion birlikte raporlanır |
| 24 | Karbon ve kolay backbone'un rare elementleri örtmesi | Aynı token MLM içinde rol bazlı ölçümler bulunur | Üç seed'de protein sidechain N/O/S recall `0`; normal CE sidechain içindeki karbon çoğunluğunu tercih ediyor | Tek head korunur. Real protein-sidechain ve RNA-base gruplarında `0.5*micro CE + 0.5*present-element macro CE`; grup toplam atom-count payı korunur. Backbone/UniMol değişmez, V ayrı `0.2` kalır | YENİ optimizasyon düzeltmesi | Formül unit testi; C yanında N/O/S recall; backbone/UniMol regresyonu; gerçek representation-gradient audit'i |
| 25 | `V=120`, mask `0`, padding semantiği | Ayrı vocab tokenları | MIND encoder `x==0` değerini bazı GBF yerlerinde padding gibi ele alırken mask node attention'da aktiftir; implicit davranış tutarsız olabilir | `geometry_valid_mask` atom id'den türetilmemeli; açık role maskesi kullanılmalı. `0` yalnız atom-type mask tokenı, `120` yalnız V label/tokenı olmalı | YENİ açıklık | Masked real ile masked V forward role maskeleri aynı; dense padding node'ları ayrı maskeli |
| 26 | Positional/slot sırası ve canonical mapping | Per-atom position embedding mevcut | Exact14/23 olmayan veya atom sırası bozuk block, yanlış slot target ve anchor eşleşmesi üretir | Yalnız doğrulanmış exact14/23 canonical block MLM target olabilir; malformed block açık quarantine metriğiyle görünür olmalı | Mevcut MIND mapping + DG fixed length | 20 AA ve 4 RNA round-trip slot testi; quarantine oranı ve nedenleri |
| 27 | Visible context V residue kimliğini gösteriyor mu? | Evet, açık residue'da V tokenları görünür | Komşu residue'nın V sayısı onun tipini gösterebilir | Bu target leakage değildir; context residue zaten gerçek atom tipleriyle açık. Yine de V yalnız categorical invariant context olur, fiziksel graph olmaz | DG | Masked target değiştirilince context V inputu sabit; yalnız context residue değişince değişebilir |
| 28 | Cross-domain davranış | Protein/RNA fixed slot, small molecule normal token | Global geometry mask yanlış domain'e uygulanırsa UniMol atomları düşebilir | Role mask yalnız exact protein/RNA block ve V id/slot metadata ile domain-gated uygulanmalı; diğer domainler bitwise legacy | YENİ | Aynı seed UniMol batch forward/loss bitwise eşit |
| 29 | Compute/memory şişmesi | Daha uzun sequence maliyetini kabul eder | V ve masked query node'ları attention/belleği büyütür | Raw `.pt` exact14/23 kalır; runtime compaction visible V ile masked side/base slotlarının tamamını encoder'dan çıkarır. Sabit çıktı latent readout'ta korunur | YENİ | Raw/active atoms, edges/s, peak VRAM ve p50/p90 step süresi raporu |
| 30 | Overall accuracy'nin yanıltması | Role bazlı loss/metric kodu var | Çok sayıda V ve kolay backbone, overall metriği şişirebilir; template-v1 CB'yi düzeltirken SCr/BaseR düşük kalmıştır | Overall tek başına kabul metriği değildir. Slot-only baseline, per-role, exact block ve clean-distance metrikleri birlikte zorunlu | Mevcut audit + DG metric ayrımı | Aşağıdaki kabul tablosunun tamamı |

## Uygulanan forward akışı

### 1. Mask seçimi

Whole-block MLM mevcut şekilde residue/nucleotide seçer. Protein için 14, RNA
için 23 node'un atom tipi `0` mask tokenına çevrilir.

### 2. Role maskelerinin üretilmesi

Target etiketleri forward'a verilmeden şu input rolleri hesaplanır:

```text
masked_backbone_mask
masked_side_or_base_slot_mask
visible_virtual_mask
geometry_valid_mask
```

Masked side/base slot maskesi original atom tipine göre değil block içindeki
sabit slot ordinaline göre oluşturulur. Böylece gerçek/V cevabı maskeye sızmaz.

### 3. Input graph

```text
input spatial/equivariant graph
    = geometry-valid gerçek atomlar üzerinde real-only radius/hybrid graph

ESA attention tokens
    = bütün görünür gerçek atomlar + maskeli block'un backbone atomları

post-ESA latent outputs
    = seçilen block'un 10 protein / 11 RNA side-base slotu
```

Görünür V raw graph'ta exact14/23 sözleşmesi için bulunur fakat encoder'a girmez.
Maskeli block'un 10/11 side/base slotu da target real/V fark etmeden encoder'a
girmez. Böylece fiziksel graph yalnız fiziksel atomlardan oluşur. Atom sayısı
sızıntısı oluşmaz; çünkü MLM head her seçilen block için yine sabit 10/11 latent
slot çıktısı üretir.

Eski `.pt` dosyalarının node, block, slot ve gerçek koordinatları kullanılabilir.
Ancak cache spatial edge'leri V'nin neighbor kotasına etkisi yüzünden güvenilir
kabul edilemez. `.pt` üretmeden küçük test yapmak için forward'da real-only
spatial rebuild gerekir. Karar doğrulandıktan sonra production verisi atom
sunucusunda bir kez yeniden üretilebilir veya runtime rebuild kalıcılaştırılabilir.

### 4. Encoder

- Atom embedding: maskeli backbone için `0`; visible V ve maskeli side/base
  encoder active listesinde bulunmaz. `120` yalnız raw label/vocabulary ve MLM
  targetıdır.
- Fiziksel ESA: bütün local ve global context'i gerçek atom/backbone node'larında
  toplar.
- Latent slot readout:
  `q[i,k] = LayerNorm(mean(h_owner_backbone) + slot_embedding[k])`.
  Protein owner backbone'u N/CA/C/O; RNA owner backbone'u sabit 12 backbone
  atomudur. Bu işlem koordinat yerleştirme değildir.
- Geometric node features: yalnız geometry-valid graph.
- Equivariant branch: yalnız geometry-valid edge/vector.
- Centering: yalnız geometry-valid node'ların merkezi.
- Distance bias/PE: kapalı veya aynı role maskesiyle güvenli.

### 5. Tek MLM çıktısı

Yeni occupancy head yoktur:

```text
prediction in {0..120}

120       -> V
1..119    -> element/rare mapping
```

Mevcut `real_loss + virtual_atom_loss_weight * virtual_loss` dış ölçeği korunur.
Real sidechain/base bölümünün kendi içinde:

```text
group_loss = 0.5 * normal atom ortalaması
           + 0.5 * batch'te bulunan elementlerin eşit ortalaması
```

uygulanır. Bu grup real loss içindeki eski atom-sayısı payını korur; backbone ve
UniMol normal CE ile, V ise ayrı `virtual_atom_loss_weight=0.2` ile devam eder.

### 6. Hidden clean-distance hedefi

Input graph ile supervision graph birbirinden ayrılır:

```text
input_edge_index      -> modelin gördüğü real-only fiziksel graph
target_pair_index     -> loss için temiz koordinatlardan seçilen pair'ler
target_pair_distance  -> yalnız label
```

Örnek:

```text
masked slot s2
input atom type: [MASK]
input spatial edge: yok

MLM target: O
distance targets:
    d(s2, CA) = 2.43 A
    d(s2, aynı block'taki diğer backbone anchorları) = ...
```

Target `V` ise yalnız MLM target vardır; physical distance target yoktur.

Bu görev koordinat üretmez. MIND'ın mevcut amacıyla uyumlu biçimde atom
embedding'ine hidden 3B ilişki öğretir. Tam koordinat üretimi istenirse bu belge
yeterli değildir; BoltzGen benzeri diffusion ayrı bir model değişikliğidir.

## Mevcut seçeneklerin hükmü

| Seçenek | Hüküm | Neden |
|---|---|---|
| V'yi CB/C1'/N/CA/C/O üzerine koy ve graph'a bırak | **Reddedildi** | Sıfır mesafe, anchor çöküşü, neighbor starvation ve geometry leakage |
| V'yi backbone'a koy, yalnız V edge'lerini sonradan sil | **Reddedildi** | Cache kurulurken kaybolan real-real edge'leri geri getirmez; COM/RBF/equivariant/bias kanalları açık kalabilir |
| Mevcut sentetik template-v1 | **Production çözümü olarak reddedildi** | Leakage'i azaltır ama sahte input kimyası verir ve gerçek masked side/base geometrisini targetsız siler |
| Diğer grubun anchor koordinatlarını MIND graph'a aynen kopyala | **Reddedildi** | Diğer grupta bu koordinatlar masked target'tır ve spatial graph üretmez; MIND'da temiz input shortcut/edge olur |
| Literal BoltzGen protein diffusion | **Teknik olarak mümkün, bu işin hızlı çözümü değil** | Yeni coordinate diffusion, equivariant output, dynamic graph ve decoder gerekir; RNA marker şeması yok |
| Geometry-neutral fixed-slot MIND sözleşmesi | **Uygulandı; eğitim doğrulaması bekliyor** | Sabit slotu korur, V'yi fiziksel atom yapmaz, tek MLM'i korur ve gerçek geometriyi yalnız target olarak kullanır |

## Uygulama durumu ve dürüst sınır

Kod düzeyinde çözülen bölüm şudur:

- görünür V encoder token listesinden compact ediliyor;
- maskelenen protein/RNA block'unda yalnız 4/12 backbone node'u encoder'da
  kalıyor; 10/11 side/base çıktısı latent readout olarak üretiliyor;
- maskeli sidechain/base slotu real veya V hedefinden bağımsız olarak COM, edge,
  RBF ve equivariant geometry kanalından çıkarılıyor;
- latent slot, kendi owner backbone'unun ESA çıktısını canonical slot embedding'i
  ile birleştiriyor; owner routing artık FlashAttention/adjacency davranışına
  bağlı değil;
- cache'te V'nin tükettiği komşu kotasını telafi etmek için protein Tier-2 ve RNA
  radius kenarları yalnız fiziksel atomlardan runtime'da tamamlanıyor;
- gizli gerçek slot koordinatları input'a değil, mevcut distance head'lerine aynı
  block backbone hedefi olarak gidiyor; V slotları distance target üretmiyor;
- UniMol graph'ında node, edge ve geometry görünümü korunuyor;
- gerçek sidechain/base MLM içinde karbon çoğunluğunu dengeleyen fakat grup
  ölçeğini değiştirmeyen element-macro CE ekleniyor;
- ilk training batch'inde her weighted task'ın shared node-state gradient L2
  normu diagnostic olarak ölçülebiliyor;
- sentetik template-v1 iki ana eğitim config'inde kapalı.

İlgili implementasyon:

- `core/virtual_slot_graph.py`
- `core/pretraining_model.py`
- `core/molecular_encoder.py`
- `core/pretraining_tasks.py`
- `core/pretraining_config.py`
- `tests/test_geometry_neutral_virtual_slots.py`

Bu noktada **"V artık kesin iyi öğrenilir"** denemez. Kapatılan şey yanlış/sahte
bilginin forward'a girmesidir. Modelin context kullanarak aminoasit ve nucleotide
kimliğini yeterince öğrenip öğrenemeyeceği ampirik sorudur. Aşağıdaki iki sonuçtan
biri görülürse V yaklaşımını uzatmadan bırakmak mantıklıdır:

1. kısa gerçek-data eğitiminde SCr/BaseR eski template-v1'e göre iyileşmez veya
   backbone/UniMol metrikleri belirgin bozulur;
2. latent readout sürümünde context-shuffle testi SCr/BaseR/CE'yi bozmaz; yani
   model hâlâ slot marjinalini ezberliyor ve backbone context'ini kullanmıyordur.

Bu durumda V'yi yalnız koddan silmek yeterli değildir: variable-size residue atom
sayısı tekrar hedefi ele verir. Temiz alternatif ya residue-level ayrı bir hedef
tasarımı ya da BoltzGen ölçeğinde coordinate generative modeldir. Bunlar hızlı
patch değildir; başarısızlık raporunda açıkça kapsam dışı olarak yazılmalıdır.

## Zorunlu kabul kapıları

Hiçbir uzun eğitim bu küçük doğrulamalar geçmeden başlatılmamalıdır.

### A. Bilgi sızıntısı ve sahte geometri

| Test | Geçme ölçütü |
|---|---|
| Placeholder perturbation | Masked side/base ve visible V placeholder koordinatlarını değiştirince forward logits bitwise veya sayısal tolerans içinde aynı |
| Target swap | Aynı context/backbone üzerinde real/V target etiketleri değiştirilince forward input graph/features aynı |
| V-edge audit | Spatial/equivariant graph'ta V endpoint sayısı `0` |
| Real-edge equivalence | Runtime graph, V hiç eklenmemiş real-only radius/hybrid referansıyla aynı |
| COM invariance | V/placeholder perturbasyonu centered real coordinates'ı değiştirmiyor |
| Loss-only clean geometry | `clean_pos` veya target pair değişikliği forward logits'i değil yalnız distance loss'u değiştiriyor |

### B. Öğrenilebilirlik

| Test | Amaç |
|---|---|
| Masked-slot context gradient | Latent slot loss'u kendi owner backbone'una gradient gönderiyor |
| Slot-only baseline | Model yalnız canonical slot marginalini ezberleyerek ne kadar skor alabiliyor? |
| Context shuffle | Context bozulduğunda SCr/BaseR ve exact-block belirgin düşmeli; düşmüyorsa model context öğrenmiyor |
| Per-slot confusion | Hangi slotların otomatik V/element ezberine dönüştüğü görülmeli |
| Distance head | Masked-real target pair loss'u finite/nonzero; V physical loss'u sıfır |

### C. Ana metrikler

- Protein backbone N/CA/C/O recall.
- Protein real sidechain `SCr`; CB ayrıca.
- Protein V recall/precision.
- Amino-acid real-only ve all-slot exact accuracy.
- RNA backbone ve `C1'`.
- RNA real base `BaseR`.
- RNA V recall/precision.
- Nucleotide real-only ve all-slot exact accuracy.
- Masked-real short/anchor ve long-distance bin accuracy/MAE.
- Her metrik için support; overall accuracy tek başına kullanılmaz.

### D. Performans ve domain güvenliği

- UniMol aynı seed/config altında bitwise legacy davranışı korumalı.
- Protein/RNA graph edge sayıları ve V endpoint sayısı raporlanmalı.
- Atoms/s, edges/s, peak VRAM, data-wait ve step p50/p90 ölçülmeli.
- Runtime rebuild'in eski PT kullanımında gerçek edge doğruluğu kanıtlanmalı.

## Güncel kod doğrulaması

```bash
MPLCONFIGDIR=/tmp/mind_mpl \
  /opt/anaconda3/envs/mind_esa3d/bin/python -m pytest -q \
  tests/test_geometry_neutral_virtual_slots.py \
  tests/test_virtual_atom_stage3.py \
  tests/test_virtual_slot_diagnostics.py \
  tests/test_flash_varlen_attention_scope.py
```

Sonuç: özellik odaklı pakette **61/61**, repo genelinde **152/152** test geçti.
Kapsam; protein ve RNA active/geometry maskeleri,
visible-V compaction, real-only radius edge restoration, COM/placeholder
invariance, latent slot full-index scatter, owner-backbone gradienti, V'siz
distance pair routing, hidden-real distance gradienti, slot/block-balanced
distance reduction, element-balanced MLM formülü, protein CA sequence/random
tier koruması, stale spatial edge temizliği,
malformed block quarantine, gerçek PyG protein+UniMol mixed-batch regresyonu,
UniMol graph-view regresyonu ve eski/yeni yöntemin aynı anda açılmasını engelleyen
config guard'dır.

Önceki query-node sürümü gerçek `.pt` ve GPU eğitimlerinde çalışmış, fakat
context kullanımını öğrenememiştir. Güncel latent-readout + balanced-loss
sürümünün gerçek ESA/FlashAttention GPU forward-backward'ı, throughput/VRAM ve
öğrenme metrikleri henüz doğrulanmadı. Bunlar açık kabul kapılarıdır.

## Kaynak ve kod referansları

### MIND

- Protein V'nin CB/CA üzerine konması:
  `data_loading/adapters/protein_adapter.py`, `_standardize_residue_to_14_atoms`.
- RNA V'nin C1'/fallback üzerine konması:
  `data_loading/adapters/rna_adapter.py`, `_standardize_residue_to_23_atoms`.
- Cache radius/hybrid graph ve neighbor limitleri:
  `data_loading/cache_to_pyg.py`, `_build_hybrid_edges` ve `_universal_to_pyg`.
- Atom masking ve block masking:
  `core/pretraining_model.py`, `_ensure_mlm_attributes`.
- COM centering ve encoder çağrısı:
  `core/pretraining_model.py`, `forward`.
- Coordination/RBF/geometric node features:
  `core/molecular_encoder.py`, `_compute_geometric_features`.
- Equivariant edge vectors ve invariant branch:
  `esa/equivariant_sab.py`, `EquivariantSAB.forward`.
- Flash-varlen adjacency sınırlaması:
  `esa/mha_flash_varlen.py`, `_forward_varlen`.
- Tek MLM ve virtual loss weighting:
  `core/pretraining_tasks.py`, `mlm_loss`.
- Template node'ların mevcut distance loss'lardan çıkarılması:
  `core/pretraining_tasks.py`, `long_range_distance_loss`; ayrıca
  `core/pretraining_model.py`, `_compute_pretraining_losses`.
- Current template-v1'in type-independent sentetik olduğu:
  `core/virtual_atom_templates.py`.
- Mevcut run auditi ve SCr/BaseR sonuçları:
  `Docs/features/MULTIDOMAIN_VIRTUAL_V1_RUN_AUDIT.md`.

### Diğer grup

- Protein `residue_padded_all`, 14 slot ve ModernBERT config:
  `repomix-output.xml` yaklaşık satır 3003.
- Atomların `[element,x,y,z]` blokları olarak 14/23'e doldurulması:
  `repomix-output.xml` yaklaşık satır 13670.
- Seçilen residue'nun bütün tokenlarının maskelenmesi:
  `repomix-output.xml` yaklaşık satır 14793.
- Real/virtual atom ve coordinate loss ayrımı:
  `repomix-output.xml` yaklaşık satır 23830.
- Protein N/CA/C ve RNA P/C4'/N9-N1 custom anchor kuralları:
  `repomix-output.xml` yaklaşık satır 24507.

### BoltzGen

- Protein fake-marker tablosu:
  <https://github.com/HannesStark/boltzgen/blob/a3149cf18eeb58648d1abbb27539bd73f746cdda/src/boltzgen/data/const.py>
- Atom14 featurization ve N/O count decoder:
  <https://github.com/HannesStark/boltzgen/blob/a3149cf18eeb58648d1abbb27539bd73f746cdda/src/boltzgen/data/feature/featurizer.py>
- Design atom masking:
  <https://github.com/HannesStark/boltzgen/blob/a3149cf18eeb58648d1abbb27539bd73f746cdda/src/boltzgen/model/modules/masker.py>
- Coordinate diffusion:
  <https://github.com/HannesStark/boltzgen/blob/a3149cf18eeb58648d1abbb27539bd73f746cdda/src/boltzgen/model/modules/diffusion.py>
- Makale:
  <https://pmc.ncbi.nlm.nih.gov/articles/PMC12697729/>

## Açıkça yeni olan parçalar

Aşağıdakiler ne BoltzGen'den ne diğer gruptan aynen alınmıştır; MIND'ın graph
yapısı nedeniyle gereken yeni entegrasyonlardır:

1. Tek `geometry_valid_mask`in COM, spatial edge, node geometry, equivariant
   branch, distance bias ve PE kanallarının tamamında uygulanması.
2. Eski cache neighbor-starvation sorununu aşmak için real-only runtime spatial
   rebuild.
3. `input_edge_index` ile clean `target_pair_index`in kesin ayrılması.
4. Mevcut distance head'lerinin masked-real slotlara clean supervision verecek
   şekilde pair routing'i.
5. Placeholder-invariance, real-edge-equivalence ve slot-only leakage testleri.
6. Encoder sonrası owner-backbone latent readout ve real side/base element-macro
   CE.

İlk altı parça uygulandı; deterministic küçük testler geçti. Slot-only ve
correct/shuffled/removed öğrenme testleri yeni kısa gerçek-data eğitimini bekliyor.
Yalnız "V edge'ini sildik" veya "V'yi backbone'a koyduk" demek sorunu çözmüş
sayılmaz.
