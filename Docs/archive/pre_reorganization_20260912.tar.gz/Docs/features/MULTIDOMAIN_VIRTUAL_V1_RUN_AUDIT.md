# Multi-domain Virtual V1 Run Audit

Date: 2026-08-15

Status: E1-E3 and E7 complete; E4 is deferred; E5 policy and E6 performance are
reopened after the 2026-08-17 long-run review; G1 passed only for the superseded
bounded-epoch policy and G2 is pending.

This document is the working technical record for the two Virtual V1 multi-domain
runs. It is deliberately detailed so that each problem can be fixed, tested, and
committed independently.

## Current situation in plain language

The Virtual V1 chemistry change did not simply make the previous training job a bit
heavier. It exposed several independent data and sampler defects at the same time.
The full run loaded all 12,869 available RNA structures instead of using a deliberate
development subset, admitted individual RNA graphs up to roughly 100k nodes, balanced
domains by graph count instead of atoms, and let Lightning stop an epoch according to
an unrelated fixed-500-atom estimate. The model therefore trained on an RNA-heavy,
partly repeated, partly truncated stream whose iteration count cannot be compared to
the old run.

The old protein policy is the right development principle: while representation and
training code are still changing, use a fixed, representative subset rather than the
entire available corpus. Protein uses 40,000 out of roughly one million suitable
structures, approximately 4%. Applying the same fraction to 12,869 RNA structures
gives **515 RNA structures**.

This subset reduction is a development policy, not a substitute for fixing oversized
graphs or the sampler. A 515-structure subset can still contain an 80k-node graph.

## Temporary RNA development subset decision

Decision update (2026-08-16): for the current "does the model learn?" phase, source
RNA output chunks `[0, 4]` inclusive are filtered by metadata with the explicit policy
`num_nodes <= 5000`. The immutable derived set at
`/home/yusuf/data/rna_small/processed_23slot_5k_chunk_000..004` contains 766 of the
1,000 source graphs, 1,508,360 nodes, and 72,015,890 edges; its largest graph has
4,933 nodes. All 766 molecule IDs are unique. The 234 oversized source graphs are
recorded, not rewritten or windowed. Production PTs remain read-only and their
fingerprints are stored in the derived manifest. This is still a source-group-0-only
development shortcut, not a representative evaluation subset. A future all-RNA run
requires E4-E7 and the validation gates before restoring `chunk_range: null`.

### Target

- Full eligible RNA population: 12,869 structures, 225,036,797 nodes.
- Population manifest SHA-256:
  `eff078bc05dd0c60f2b0479168d209d158e2c9c025a54602f83e926d268da961`.
- Source-group graph counts: 2,570 / 2,575 / 2,576 / 2,575 / 2,573.
- Current graphs above 12k nodes: 3,995 / 12,869 = 31.04%.
- Protein development fraction: `40,000 / 1,000,000 ~= 4%`.
- Historical RNA development target: `round(12,869 * 0.04) = 515` structures.
- Current filtered development selection: 766 structures from source chunks `0..4`.
- Expected pre-crop RNA nodes at the current population mean: approximately 9.01
  million.
- Storage layout: five immutable derived chunks preserving the source chunk boundary.
- Fast config: derived chunk `000` only (147 graphs, 253,504 nodes).
- Full-development config: all five derived chunks (766 graphs, 1,508,360 nodes).

Do not use `chunk_range: [0, 2]` on the current production outputs as the permanent
solution. Those are the first 600 records of source group 0 and are not source- or
length-representative. The development subset must be selected by stable structure ID
and stratified by source group and graph-length bin. It should be written to a new,
immutable manifest such as `rna_dev_4pct_manifest.csv`; production 23-slot chunks must
remain untouched.

The current five-source whole-chunk approximation would be output chunks
`0, 14, 28, 41, 54`: 1,000 graphs and 17,529,706 nodes, close to the old 18,184,350
RNA-node workload. It is useful only as a sizing cross-check, not the preferred final
development subset, because 334 of those 1,000 graphs already exceed 12k nodes.

### Which RNAs were used before?

The old audit proves that the previous cache contained 9,783 molecules in five source
PKLs (`1,957 + 1,957 + 1,957 + 1,957 + 1,955`) and 874,604 nucleotide blocks. The old
production PKLs/PTs and their molecule-ID sidecar are no longer present at their
recorded `/home/yusuf/data/rna/processed_graphs_chunk_*` paths, so the exact 9,783-ID
set cannot be reconstructed reliably from the current workspace. It must not be
guessed from filename ordering.

The new canonical manifest does provide all 12,869 current IDs. Exact overlap with
the deleted old cache is unnecessary for the development goal. The original E1 design
would have produced and versioned an exact 515-ID selection; that design was later
superseded by the temporary whole-chunk decision recorded above.

### Current development subset gates

- [x] All 766 retained structure IDs are unique.
- [x] Original structure ID and source chunk/local index are retained in metadata.
- [x] The deterministic `num_nodes <= 5000` selection rule is stored in the manifest.
- [x] Manifest SHA-256 is
  `7fb785bd4b572df414c1bbc15017041b614a44e0a281844069ddc14d219e6380`.
- [x] Production RNA PT fingerprints are recorded and source stat fingerprints are
  unchanged after filtering.
- [x] E3 passes before this subset is used for training.
- [ ] Source-group and length-bin representativeness remains intentionally deferred;
  this set is for learning checks, not representative evaluation.

## How future chats must use this report

Each new chat should handle one `E*` error package below. Before editing, the model
must read this summary and that package's checklist, state its verification criteria,
and avoid folding in another package unless the two are technically inseparable.

After the work:

- mark completed subtasks `[x]` only with test evidence;
- record commit hash, commands, artifacts, and residual risks in the package;
- leave unchecked items as `[ ]`; never mark the parent complete because only its
  implementation, but not its tests, finished;
- if a new defect is discovered that is not listed here, **tell the user explicitly
  before expanding scope**, add it to the New Defect Inbox below, assign severity and
  dependencies, then decide whether it becomes a new error package or a subtask.

### New Defect Inbox

- [x] **NEW-1 (P1, resolved in E2) — Selection-dependent index-map cache overwrites a shared
  sidecar.** The former path was derived only from the first selected chunk, so
  different mixed-domain selections could rewrite
  `/home/yusuf/data/proteins/processed_14atom_index_map.json`. E2 now keys the cache
  by the complete resolved file list and stores it outside the production tree.

## Scope and evidence

Primary runs:

- `logs/August2026/virtual_v1_multidomainfast_20260811_223719.log`
- `logs/August2026/virtual_v1_multidomain_full_20260811_233000.log`

Comparison run:

- `logs/June2026/multidomain_100ep_pdb_unimol_rna_20260609_065900.log`

Code paths inspected:

- `data_loading/improved_dynamic_sampler.py`
- `data_loading/dynamic_chunk_sampler.py`
- `data_loading/lazy_universal_dataset.py`
- `core/train_pretrain.py`
- `core/masked_coordinate_corruption.py`
- `core/pretraining_model.py`
- `core/batch_statistics_callback.py`
- current multi-domain, fast, and equivariant YAML configurations
- reachable Git history, reflog/stash, and unreachable commits for sampler and
  ratio-related changes

The RNA and protein metadata plus the current RNA manifest are available on the
mounted data volumes. The old five RNA cache files named in the historical handoff
are no longer present, which limits exact old/new molecule-ID overlap analysis.

## Executive diagnosis

The one-day runtime is not primarily evidence of RAM spilling to HDD. The run did
far more work than the earlier run, and the sampler made that work distribution much
worse:

1. The selected dataset grew from 120,436,742 to 327,289,189 metadata atoms, even
   though sample count stayed near 0.91 million.
2. Almost all of that growth came from switching RNA from five old chunks to 67
   `processed_23slot` output chunks. The 67 outputs were re-chunked from five source
   groups, so chunk count alone is not a corpus-size measure. Exact totals show that
   RNA graph count rose only 1.32x while average atoms per graph rose 9.41x. V padding
   contributes only a small part; admitting/preserving much longer RNA content is the
   main part.
3. `cycle_short_domains=True` constructs a repeated stream whose proportions are
   based on sample counts, not atom counts or YAML ratios. It over-represented very
   large RNA samples.
4. A 12,000-atom batch budget is only a packing target. A single 60k-86k RNA graph
   is silently emitted as an oversized one-graph batch.
5. The full run's observed batches averaged about 24,018 nodes; the June comparison
   averaged about 4,986. The unit represented by one `it/s` therefore became about
   4.8 times larger before considering the nonlinear attention cost of a long graph.
6. `ImprovedDynamicBatchSampler.__len__()` assumes 500 atoms per sample instead of
   using metadata. It reported 30,384 train batches, generated 63,452/63,560, and
   Lightning consumed only the reported 30,384. Thus an "epoch" is neither a full
   pass nor a deliberately defined atom budget.
7. Validation ran four times per epoch. That is intentionally retained for now, but
   in this run each validation was itself large and expensive.

Measured total epoch work explains the slowdown: approximately 730 million observed
training nodes per new epoch versus approximately 96 million in the June comparison,
about 7.6x. The comparable wall-clock slowdown is about 8.5x. Disk I/O and runtime V
templating can account for secondary overhead, but are not needed to explain the
main regression.

## Run comparison

| Property | June comparison | Virtual V1 full | Consequence |
|---|---:|---:|---|
| Chunks | 25 (10 protein, 10 UniMol, 5 RNA) | 87 (10 protein, 10 UniMol, 67 RNA outputs from 5 source groups) | Output chunk count reflects re-chunking and size |
| Samples | 908,446 | 911,532 | Essentially unchanged |
| Metadata atoms | 120,436,742 | 327,289,189 | 2.72x larger dataset by atoms |
| Configured batch budget | 6,000 | 12,000 | Not a hard per-graph limit |
| Reported train length | 60,563 | 30,384 | Both derived from fixed 500 atoms/sample |
| Actual generated train batches | about 19,329 | 63,452 / 63,560 | `__len__` disagrees in opposite directions |
| Consumed train steps/epoch | about 19,329 | 30,384 | Lightning follows the incorrect length |
| Logged mean nodes/batch | about 4,986 | about 24,018 | 4.82x more nodes per iteration |
| Logged median nodes/batch | about 5,257 | about 11,142 | Near the nominal budget |
| Logged p90 nodes/batch | about 5,989 | about 66,355 | Long-RNA tail dominates |
| Logged max nodes/batch | about 7,168 | about 86,613 | Silent oversized batches |
| Logged atom mix | PDB 66.0%, RNA 14.9%, UniMol 19.0% | PDB 10.3%, RNA 88.5%, UniMol 1.2% | Desired balance is absent |
| Observed training speed | about 3.89 it/s | about 0.71 it/s | Iterations are not comparable work units |
| Epoch wall time | about 1h23 in this comparison log | about 12h30 including validation | About 9x |

The user's remembered 45-minute baseline may refer to a different run/config. The
June log used here is the closest like-for-like multi-domain record and is about 1h23
per completed sampler stream. This distinction does not change the diagnosis.

## Why the atom count grew

### It is not only RNA V atoms

The metadata increase is exactly 206,852,447 atoms. Protein and UniMol selections
remained at ten chunks each and together account for 102,252,392 atoms in both runs.
This gives exact RNA totals of 18,184,350 old versus 225,036,797 new: 12.375x, or a
1,137.5% increase.

The old RNA audit recorded 9,783 graphs and 874,604 nucleotide blocks. The new
manifest records 12,869 graphs. Since the representation is nominally 23 nodes per
nucleotide, its node total corresponds to approximately 9.784 million nucleotide
blocks. Thus graph count rose only 1.315x, while average nodes per graph rose from
1,858.8 to 17,486.7, or 9.408x. The 67 output chunks were generated from five source
groups; they are not 67 independent source datasets.

The 23-slot RNA representation has 12 backbone/sugar/phosphate slots and 11 base
slots per nucleotide. The old corpus averaged 20.79 real nodes per nucleotide. If
exactly those 874,604 old nucleotides had merely been padded to 23 slots, the total
would be 20,115,892 nodes: only 1,931,542 extra nodes (+10.6%), not 206.9 million.
Therefore V padding cannot explain the explosion. The new build admitted/preserved
far more nucleotide content per graph; the exact preprocessing/filtering difference
that changed average graph length requires a separate manifest-level audit.

The remainder comes from including far more RNA nucleotides/structures. A validation
cross-check supports this: the new RNA table covers 138,512 nucleotides and 3,185,776
slot atoms (`138,512 * 23`). The June table covered about 539,708 RNA atoms, a roughly
5.9x difference in validation RNA work.

Runtime canonical templates do not create additional nodes. They reposition selected
V slots and update affected edges. They can add latency, but they do not explain the
metadata atom-count increase.

### Why processed atoms per epoch grew even more

Dataset metadata describes the unique selected samples. It does not describe the
sampler's repeated epoch stream. The cycling scheduler wraps shorter streams with
modulo indexing. Because its schedule is computed from sample counts and because the
domains have drastically different atoms per sample, repeated sample balance becomes
extreme atom imbalance. The full run's logged batches were 88.5% RNA atoms.

## What batch p90 means

`p90` is the 90th percentile. If batch node count has `p90 = 66,355`, then 90% of
the logged batches have at most 66,355 nodes and 10% have more. It is not the mean,
not the maximum, and not a target.

Here p90 is especially diagnostic: the median is about 11,142, close to the 12k
budget, but p90 is 66k. That shape means ordinary packed batches are near the budget
while a large tail consists of single oversized RNA graphs.

## Why real `it/s` fell

`it/s` measures optimizer batches per second, not atoms, edges, or attention work per
second. Dynamic batches make it an unsafe cross-run throughput metric.

The new observed iteration has 4.82x more nodes on average. In addition:

- FlashAttention avoids materializing the full attention matrix and improves memory
  use, but attention computation for one sequence/graph still grows approximately
  quadratically with its node count.
- Encoder, edge, masking, metric, and collate costs grow with nodes and/or edges.
- One 86k graph is computationally very different from several graphs totaling 12k.
- Runtime template mapping contains GPU-to-CPU synchronization and a Python loop.
- Dataset/chunk reads add stalls, particularly with `num_workers=0`.
- Four full validations per epoch reduce wall-clock training throughput but do not
  explain the train progress bar's instantaneous rate by themselves.

Therefore even after defining a normal-sized epoch, the old 3.9 it/s is not the right
target if batches intentionally contain twice as many atoms. Future comparisons must
log at least atoms/s, edges/s, graphs/s, optimizer steps/s, data-wait time, and p50/p90
step latency.

## RAM/HDD assessment

Available system telemetry does not show RAM exhaustion:

- process RSS peaked around 46.8 GB;
- available system RAM remained roughly 91.7 GB even at its lower decile;
- the GPU had long low-utilization windows, so CPU/data stalls are real;
- disk reads were substantial (about 1.8 TB over the run), with higher read rates in
  some GPU-low windows.

The current environment cannot resolve the physical device backing every external
data path, so it cannot conclusively label a mount HDD versus SSD. Nevertheless,
there is no evidence that system RAM filled and forced swapping. Disk/data loading is
a secondary performance issue; the 7.6x growth in processed nodes and oversized
attention workloads already explain nearly all of the wall-clock regression.

The printed `~99.97% cache hit rate` and `3.5-4.0 it/s` are hard-coded messages in
`core/train_pretrain.py`, not measurements. They must not be used as evidence.

## Dataset ratio audit

### Desired policy

The remembered target is:

- RNA 25% + protein 30% = 55% biopolymer atoms
- UniMol 32% + QM9 2% + metabolite 10% = 44% as written, not 45%

The five explicit numbers sum to 99%, not 100%. Before implementation we should
choose one explicit normalization rule. The safest interpretation is to normalize
the supplied weights, yielding approximately 30.30%, 25.25%, 32.32%, 2.02%, and
10.10%. If the group split must be exactly 55/45, one molecular subweight needs a
one-point adjustment or hierarchical within-group normalization.

### What Git history shows

The desired atom quota was never implemented in reachable repository code:

- `da6e4db` introduced dynamic batching with sample-count proportions.
- `812ed6a` introduced `ImprovedDynamicBatchSampler`; its `__len__` used fixed 500
  atoms/sample from the beginning.
- `7f8f262` introduced short-domain cycling to remove a late UniMol-only tail. It
  retained sample-count proportions and added modulo repetition.
- Searches across branches, reflog/stash, and unreachable commits found no code that
  reads YAML `atom_ratio` or implements the stated 30/25/32/2/10 atom mix.

The old YAML `atom_ratio` values were dead configuration. `core/pretraining_model.py`
uses the string `batch_<domain>_atom_ratio` only as a logged metric name; it does not
read configuration ratios.

### Current scheduling defect

The sampler computes `len(domain) / total_samples`, multiplies by an
`interleave_window` of ten, truncates to an integer, and enforces at least one slot
per enabled domain. This has several consequences:

- ratios are by graph/sample count, not atoms;
- every rare enabled domain receives at least roughly one slot per ten-slot round;
- rounding can heavily distort small target percentages such as QM9 2%;
- the number of rounds is set by whichever domain takes longest to exhaust at its
  assigned slots;
- all other domains wrap with modulo and repeat;
- epoch size is emergent rather than explicit.

This is the central correctness bug behind the observed 88.5% RNA atom mix.

### Config cleanup already made in the working tree

Dead `atom_ratio` fields and comments were removed from:

- `core/pretraining_config_fast.yaml`
- `core/pretraining_config_multidomain.yaml`
- `core/pretraining_config_equivariant.yaml`
- `Docs/features/EPOCH_BALANCED_MULTIMODAL_BATCHING.md`

The same loader/sampler path is used for fast, full, and enabled single-domain
configurations. No code reads those fields in any of these modes. The W&B metric keys
remain because they are measurements, not dead configuration.

This audit intentionally does not delete every other YAML field annotated `not used`.
That would be a wider configuration-schema change and should have its own exhaustive
read-site audit and commit.

## Oversized RNA graphs and the 12k limit

### Did the defect exist before V?

Yes. Both samplers have always treated `max_atoms_per_batch` as a batch-packing
threshold, not a hard sample-size guard. If the current batch is empty, a sample
larger than the threshold is added anyway. The June max of about 7,168 under a 6,000
budget proves the behavior was already present.

Previously it was mostly harmless because the largest expected protein is about
`512 residues * 14 slots = 7,168` nodes, only a small overshoot. The expanded 23-slot
RNA dataset exposed the latent defect with ribosome-scale graphs: 86,613 nodes is
about 3,766 nucleotides.

### Why it did not OOM

The run used BF16 and FlashAttention on a roughly 49 GB GPU. FlashAttention does not
store a full dense N-by-N attention matrix, so a single 60k-86k sequence can fit even
though its computation is very slow. The observed allocated GPU memory was near the
device limit, so survival is not a correctness guarantee. A somewhat larger graph,
more edges, or a different kernel can still OOM.

### Historical long-RNA optimizations already in effect

The earlier long-RNA optimization was real, but it did not crop or window a graph.
Commit `e73283a` routed RNA/large-molecule geometric feature construction through
sparse `edge_index` operations instead of building dense pairwise-distance tensors.
Commit `030acc1` then made that sparse path common to every domain, and the current
implementation remains in `core/molecular_encoder.py`. The current RNA caches also
cap local neighbors during edge construction, and the audited multidomain run used
BF16 plus `flash_varlen` attention. These changes explain why very large RNA graphs
can survive in memory better than a naive dense implementation.

There was also a separate `molecule_max_atoms` filter in the RNA-only config: it was
reduced from 5,000 to 1,000 in commit `b9fc39c`. That filter applies while converting
raw molecules to a cache. It is not enforced by the current multidomain lazy loader,
and the production 23-slot caches were built without such a cap; their metadata
therefore legitimately contains 60k-100k-node graphs.

The audit's runtime diagnosis already includes the active optimizations: it used the
actual optimized run logs and explicitly accounted for FlashAttention. The historical
sparse-geometric path was not named in the original prose, but it was active in the
measured code. It reduces geometric/edge feature memory from dense pairwise work to
edge-proportional work; it does not make global self-attention linear, enforce the
12k packing target on a single graph, or repair sampler ratios. Therefore it does not
invalidate the oversized-RNA diagnosis or remove the need for E3/E4 before restoring
all RNA chunks.

### Correct solution

Do not silently let the sampler decide data semantics. Use two distinct concepts:

1. `max_graph_atoms` is a hard dataset/model compatibility invariant.
2. `max_atoms_per_batch` is a packing/throughput target for graphs that already
   satisfy the invariant.

For 23-slot RNA and a 12k graph cap, the maximum whole-nucleotide window is
`floor(12000 / 23) = 521` nucleotides. Long RNA should be converted into valid
subgraphs before batching. A production design should:

- preserve complete nucleotide blocks;
- use sequence windows or spatially coherent patches;
- rebuild/filter all edge types and graph-local metadata;
- optionally sample different windows across epochs;
- retain structure IDs and crop coordinates for provenance;
- define how cross-window long-range information will be learned;
- report dropped/cropped counts and length quantiles.

Until this exists, the sampler should fail fast with sample ID, domain, node count,
and cap. Silent oversized execution is worse than an explicit data error.

## The fixed-500 `__len__` defect

The concern is confirmed. Both `ImprovedDynamicBatchSampler` and its fallback use:

```text
floor(number_of_samples * 500 / max_atoms_per_batch)
```

This estimate is unrelated to current metadata and is catastrophically wrong for
23-slot long RNA.

Metadata is still used by `_get_atom_count_fast()` while packing the actual batches.
So metadata creation is not pointless: it avoids loading graph chunks just to know
sample sizes and supports chunk mapping and atom-aware packing. The bug is that
`__len__` bypasses the same authoritative data.

The run proves the impact:

- `len(train_loader)`/Lightning epoch length: 30,384;
- sampler-created epoch 0 batches: 63,452;
- sampler-created epoch 1 batches: 63,560;
- batches actually consumed each epoch: 30,384.

In the June run the error went the other direction: 60,563 reported versus about
19,329 generated, so iteration ended early and the progress bar showed about 32%.
This explains why the issue was visible but easy to dismiss as cosmetic. In the new
run it changes which data is trained on and therefore becomes a model-correctness
problem.

### Recommended implementation

Build one deterministic epoch plan from metadata and cache it:

- `set_epoch(e)` invalidates the plan;
- `__len__()` builds/returns `len(plan)`;
- `__iter__()` yields that exact same plan;
- calling `len()` must not advance RNG or create a different order;
- train/validation/test use the same invariant;
- both sampler implementations are fixed together, or the fallback is removed.

The batch plan is already materialized as a Python list in `__iter__`, so caching the
authoritative plan does not introduce a fundamentally new memory cost.

Required tests:

- `len(sampler) == sum(1 for _ in sampler)` for single and multi-domain modes;
- all planned batches respect the hard graph policy and packing policy;
- single-pass mode visits each sample exactly once;
- balanced mode repeats only according to explicit quotas;
- the same epoch/seed is deterministic;
- changing epoch changes shuffled order without changing intended quotas;
- subset indices map correctly;
- validation/test never cycle;
- empty and one-sample datasets behave correctly.

## Runtime V-template performance

The current masked-template path does expensive host work inside every GPU batch:

- string position codes are flattened in Python;
- `clean_pos.detach().cpu()` copies/synchronizes all coordinates;
- batch/block tensors are copied to CPU and converted to Python lists;
- a Python loop walks nodes and maps slot names;
- targeted edge rebuild uses distance operations against graph nodes.

Moving the exact current algorithm wholesale to GPU is not the best design because
strings and Python dictionaries are not GPU-friendly. The best path is to remove
runtime parsing:

1. During cache construction, store compact numeric `domain_id`, `slot_id`,
   block/residue ownership, eligibility, and local frame-anchor indices.
2. Precompute positions and edges for all visible virtual slots.
3. At training time, select masked blocks with tensors and use GPU gathers plus a
   batched local-frame transform only for affected nodes.
4. Rebuild only affected edges with a radius/neighbor kernel; avoid `cdist` against
   every node of an enormous graph.
5. Eliminate `.cpu().tolist()` and string mapping from the hot path.

An alternative is to run the mapping entirely before host-to-device transfer in
DataLoader workers, but current `num_workers=0` and repeated dynamic corruption make
that less attractive. Static numeric metadata plus minimal GPU transforms is the
cleaner target.

The current log reports about 9.68 ms average for only the targeted edge-rebuild
timer and about 0.163 total hours. That timer does not include all mapping/sync work,
so it cannot exonerate the whole V path. However July control/treatment fast runs
were both around 2.3 it/s at approximately 10.8k nodes/batch, whereas August V1 was
about 1.05 it/s at approximately 22.4k nodes/batch and 79% RNA. This indicates that
workload composition is the primary regression and template code is a secondary
optimization.

Required benchmark:

- same fixed sample IDs and batch plan;
- templates off versus current templates versus vectorized templates;
- warmup followed by at least 20 measured steps;
- report total step p50/p90, data wait, template mapping, edge rebuild, forward,
  backward, atoms/s, and GPU utilization;
- synchronize only around benchmark timing, not in production.

## Validation frequency

The full config validates at `val_check_interval = 0.25`, so two epochs generate
eight validations. The actual validation plan contained 1,672 batches, not the
reported 3,798. Each full validation took roughly 42 minutes; together they account
for about 5.6 hours.

Per the current decision, keep four validations per epoch for now. First fix epoch
semantics, ratio balance, and oversized RNA. Once those are stable, validation can be
accelerated without reducing frequency through a fixed stratified validation subset,
less verbose callbacks, cached metric state, or a separate full-validation cadence.

## Metric-table interpretation

### What is fixed

The original protein CB-to-V collapse is fixed in these runs:

- full protein CB recall: 1.0000;
- full protein V recall: 0.8618;
- fast protein CB recall: approximately 0.9996;
- June comparison CB recall: approximately 0.2801.

This is strong evidence that the virtual-template geometry removed the old CB/V
ambiguity. It does not mean the representation is fully solved.

### Remaining protein issues

- Backbone accuracy is exactly 1.0, which is expected to be easy under the current
  block/template geometry and should not dominate model-quality interpretation.
- Real sidechain atom accuracy (`SCr`) is 0.6941, the meaningful atom-level signal.
- Residue-level real-only exact accuracy is 0.4294.
- Many amino acids have zero residue-level exact accuracy despite respectable
  atom-level accuracy.
- Predictions show discrete/archetypal patterns: ALA/GLY and ILE/LEU/PRO/VAL are
  recognized well while many chemically distinct residues collapse. This suggests
  shortcut/template learning or insufficient chemical discrimination, not merely a
  V-placement failure.
- Protein V recall 0.8618 is useful but not saturated. All-slot exact residue
  accuracy is penalized heavily by any V miss, so it should be reported separately
  from real-only chemistry.

### Remaining RNA issues

- RNA V recall is 0.8895, so V prediction is broadly working.
- Backbone accuracy is 0.9990 and base-slot accuracy is 0.6784.
- Real base atom accuracy (`BaseR`) is 0.6423.
- Strict real-nucleotide exact recognition is only about 0.0447.

Thus the model reconstructs many individual real atoms but rarely reconstructs every
real base atom in a nucleotide correctly. V leakage/collapse is no longer the only or
main quality problem.

### Metric caveats

- `SC` and `Base` include padding V atoms and can look artificially strong.
- `SCr`, `BaseR`, and real-only exact residue/nucleotide metrics are the important
  chemistry signals.
- Exact-block accuracy shrinks multiplicatively with block size and is much harsher
  than atom accuracy; it must not be compared numerically as if it were the same
  metric.
- Domain imbalance means aggregate losses are dominated by RNA exposure and cannot
  fairly summarize all domains.

## Will 50-100 epochs solve general chemistry?

Two epochs are too few for a fair foundation-model conclusion, and the losses do
improve:

- train total loss moves roughly 2.20 to 2.04 in the full run;
- best validation loss improves roughly 2.943 to 2.734;
- the fast run also shows strong early loss reduction.

However the eight within-run validation measurements do not show a clean rising
trend in the meaningful chemistry metrics:

- protein macro recall stays near 0.35;
- protein `SCr` stays near 0.69;
- RNA macro/BaseR metrics fluctuate rather than improve monotonically.

Therefore it is not justified to claim that simply extending this exact run to
50-100 epochs will repair the scores. It would repeat the wrong RNA-heavy sampler,
train on truncated epoch plans, and spend huge compute on oversized graphs.

Longer training should help after correctness fixes. The older long run shows losses
continuing to improve over many epochs, which supports additional optimization value,
but it is not an apples-to-apples proof for the new representation. The correct test
is a controlled learning curve after sampler repair:

- checkpoints at 1, 2, 5, 10, 20, 50, and 100 effective atom-normalized epochs;
- fixed validation set and masks/seeds;
- per-domain losses and real-only metrics;
- samples/atoms seen per domain reported cumulatively;
- a chemistry metric slope and confidence interval, not only final loss.

If `SCr`, `BaseR`, and exact real-block scores plateau by 5-10 corrected epochs while
loss continues down, the likely problem is task/representation shortcut learning,
class imbalance, or model capacity/objective design rather than insufficient epochs.

## Additional defects found

### P0: wrong epoch definition and data truncation

The fixed-500 `__len__` and separately generated plan change training semantics. This
must be fixed before any expensive run.

### P0: silent oversized samples

The budget is presented as a safety control but is not enforced for a single graph.
Add a hard policy and preprocess long RNA.

### P0: sample-balanced cycling masquerades as multi-domain balance

The desired atom ratios are absent. Implement explicit atom quotas and an explicit
epoch atom budget; do not derive training policy from raw graph counts.

### P1: small-window minimum distorts rare domains

`max(1, int(proportion * 10))` makes a 2% domain impossible to represent faithfully
inside each ten-slot round. A quota accumulator should operate in atoms over the full
epoch, with bounded local mixing only as a secondary constraint.

### P1: batch summary callback drops the data it later aggregates

`BatchStatisticsCallback.on_train_batch_start()` computes per-domain stats but stores
only batch index, epoch, node count, and graph count. `on_train_end()` then searches
for domain keys that were never stored, producing an empty/misleading summary. The
broad `except Exception: pass` also hides callback failures. This should be fixed and
unit-tested independently.

### P1: misleading performance telemetry

The training loader prints a hard-coded cache-hit percentage and expected it/s. Log
measured cache hits, misses, load time, collate time, and atoms/s, or remove the claims.

### P1: fallback sampler duplicates the same defects

`DynamicChunkAwareBatchSampler` also has fixed-500 `__len__`, sample-count cycling,
and silent oversized behavior. Fix both samplers together or remove the fallback so
future configuration changes cannot silently restore the bug.

### P1: batch-plan construction is described inaccurately

Comments claim on-the-fly generation/cache optimization, but both samplers materialize
all batches. In the improved sampler the mixed stream alternates domains; that is not
automatically cache-local. Measure chunk hit/miss behavior before retaining the claim.

### P1: epoch callback attachment can be fragile after loader recreation

`ChunkSamplerEpochCallback` looks for a custom `batch_sampler_obj` attribute. The
pre-training "critical fix" can recreate the DataLoader but does not explicitly attach
that custom attribute in the recreation branch. Current logs show epoch-specific
plans, so this did not freeze the audited run, but the contract is fragile. Prefer
using `train_loader.batch_sampler` directly and assert `set_epoch()` was called.

### P2: runtime template timing is incomplete

Only edge rebuild is timed. Whole-stage timing is needed before optimization choices.

### P2: excessive per-batch console output

Per-domain loss and batch tables produce very large logs. Logging can synchronize and
consume CPU/disk. It is unlikely to explain the main 8.5x slowdown, but should be
reduced after correctness work.

## Trackable repair packages

There are **7 independent error packages** and **2 validation gates**. Therefore:

- 7 error packages must be resolved;
- then G1 is the corrected fast multi-domain training gate;
- then G2 is a corrected one-full-epoch pilot;
- only after all 9 checklist rows pass should a 50-100 epoch run start.

Current progress:

- [x] E1 — Temporary RNA development reduction for learning checks
- [x] E2 — Authoritative sampler epoch plan and loader lifecycle
- [x] E3 — Hard oversized-graph policy and metadata audit
- [ ] E4 — Long-RNA subgraph/window preprocessing — deferred until post-full-train review
- [x] E5 — Explicit atom-ratio and epoch-budget sampler
- [x] E6 — Correct batch statistics and measured performance telemetry
- [x] E7 — Vectorized V-template hot path
- [x] G1 — Corrected fast multi-domain validation
- [ ] G2 — Corrected one-full-epoch pilot before long training

Each E package should normally produce one focused commit. If a package requires
multiple commits, list all hashes under its evidence field.

### E1 — Temporary RNA development reduction for learning checks

Status: complete for the current development scope. By user decision, the original
stratified 515-ID manifest design was superseded first by a whole-chunk shortcut and
then by the E3-derived `[0, 4]`, `<=5000` set. This does not claim that the selected
graphs are representative.

- [x] Configure the full-development RNA input as derived chunks `[0, 4]`.
- [x] Verify that the loader's inclusive slice resolves chunks `000..004`.
- [x] Verify the selection contains 766 graphs and 1,508,360 nodes.
- [x] Record that no retained graph exceeds 5k nodes and the maximum is 4,933.
- [x] Leave the production PT files unchanged and keep long-RNA safety in E3/E4.
- [x] Record that the selection is source-group-0-only and suitable only for learning
  checks, not representative evaluation.

The former stable-ID/stratification/manifest requirements are retired from the current
development path, not silently treated as completed. A future all-RNA run does not
need a 4% manifest, but must still pass E2-E7 and G1/G2.

Evidence: YAML parse and exact metadata assertions passed for derived chunks
`000..004`; the combined loader discovers all 25 configured chunks and 899,429
graphs. `git diff --check` passed. Commit: pending.

### E2 — Authoritative sampler epoch plan and loader lifecycle

Status: complete. Domain ratios, cycling policy, and the explicit epoch atom budget
remain intentionally unchanged for E5.

- [x] Build one deterministic metadata-derived plan per epoch.
- [x] Make `__len__()` equal the number of batches yielded by `__iter__()`.
- [x] Ensure calling `len()` does not consume RNG or change the plan.
- [x] Fix both improved and fallback samplers, or remove the unsafe fallback.
- [x] Make epoch propagation use the actual loader batch sampler.
- [x] Assert `set_epoch()` after any Lightning/DataLoader recreation.
- [x] Key index-map caches by the complete selected file list (or store them in a
  run-specific cache directory) so subset/full runs cannot overwrite one shared
  production-adjacent sidecar (`NEW-1`).
- [x] Test two different chunk selections back-to-back without cache collision.
- [x] Test train, validation, test, subset, empty, single-sample, and single-domain modes.
- [x] Test same seed/epoch determinism and different-epoch reshuffling.

Evidence: `tests/test_dynamic_sampler_epoch_plan.py` passes 6/6 tests under the
`mind_esa3d` environment. It covers both sampler implementations, exact loader length,
plan reuse/invalidation, RNG isolation, all requested split/edge modes, two distinct
index-map selections, and a minimal Lightning run in which all 4 reported batches
produce 4 optimizer steps. `tests/test_atom_position_vocab.py` passes 8/8 adjacent
tests; `py_compile` and `git diff --check` pass. The index maps now default to
`~/.cache/mind/index_maps` (overridable with `MIND_INDEX_MAP_CACHE_DIR`) and include a
SHA-256-derived complete-selection key. Full fast/multidomain training is intentionally
deferred to G1 because E3-E5 correctness work is still pending. Commit: pending.

### E3 — Hard oversized-graph policy and metadata audit

Status: complete for the current development configuration. Long-RNA windowing for a
future full-corpus run remains E4.

- [x] Introduce a hard `max_graph_atoms` invariant distinct from batch packing.
- [x] Never silently pass an oversized sample as a one-graph batch.
- [x] Fail with structure ID, domain, node count, pre-split scope, configured limit,
  chunk path, and local index.
- [x] Audit p50/p90/p95/p99/max and oversized counts for every enabled domain.
- [x] Audit the configured RNA development selection before graph materialization.
- [x] Define explicit behavior for every split: filter RNA once before splitting and
  apply the same metadata fail-fast guard to the shared train/validation/test source.
- [x] Add tests for exactly-at-limit and one-over-limit graphs.

Policy and artifacts:

- PDB and UniMol hard limit: 12,000 nodes; RNA hard limit: 5,000 nodes.
- Source RNA selection: production output chunks `000..004`, 1,000 graphs.
- Derived RNA selection: 766 kept, 234 dropped, 1,508,360 nodes, 72,015,890
  edges, maximum 4,933 nodes, 1.5 GB on disk.
- Derived base: `/home/yusuf/data/rna_small/processed_23slot_5k`.
- Manifest: `/home/yusuf/data/rna_small/processed_23slot_5k_manifest.json`.
- Source PTs are loaded read-only; derived PTs are re-collated without changing graph
  tensors or regenerating the RNA representation.

Configured full-development metadata audit:

| Domain | Graphs | Nodes | p50 | p90 | p95 | p99 | Max | Over limit |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| PDB | 40,000 | 79,281,230 | 1,610 | 3,724 | 4,592 | 6,090 | 7,168 | 0 / 12k |
| UniMol | 858,663 | 22,971,162 | 26 | 35 | 38 | 45 | 76 | 0 / 12k |
| RNA filtered | 766 | 1,508,360 | 1,725 | 3,240 | 3,585 | 4,528 | 4,933 | 0 / 5k |

Evidence: all five derived PTs were reloaded and all 766 graphs passed tensor shape,
edge-bound, finite-value, molecule-ID, per-chunk metadata, aggregate metadata, and
hard-limit checks. A combined `LazyUniversalDataset` loaded 25 chunks / 899,429
graphs with complete metadata and all configured domain guards. The new exact-limit
and one-over-limit tests plus the adjacent E2 sampler suite pass 8/8 under
`mind_esa3d`; `py_compile`, YAML assertions, and `git diff --check` pass. Training is
intentionally deferred to G1. Commit: pending.

### E4 — Long-RNA subgraph/window preprocessing

Status: deferred until after the first full training run. E3 is complete; the current
filtered RNA set will be used without long-RNA windowing. Reopen E4 only after
evaluating the full-run learning curves, per-domain metrics, runtime, and RNA coverage.
Oversized molecules therefore remain deliberately excluded for this run rather than
windowed; this is an explicit experiment decision, not a completed E4 implementation.

- [ ] Choose whole-nucleotide sequence windows or spatially coherent patches.
- [ ] Keep each produced graph at or below `max_graph_atoms`.
- [ ] Preserve original molecule ID, source group, and window/patch coordinates.
- [ ] Reindex block, atom, entity, batch, and every edge type consistently.
- [ ] Rebuild/filter sequence, spatial, and long-range edges without cross-window leaks.
- [ ] Define overlap and epoch-varying window policy without validation leakage.
- [ ] Report structures-to-windows expansion and retained/dropped atom counts.
- [ ] Materialize immutable development windows/chunks from the current `[0, 4]`
  source selection without modifying production chunks.
- [ ] Add fast/full-development config paths without modifying production chunks.
- [ ] Validate one real chunk for slot counts, V positions, NaN/Inf, and edge integrity.
- [ ] Run adapter/cache smoke checks required by `validate-feature`.

Evidence/commit: pending.

### E5 — Explicit atom-ratio and epoch-budget sampler

Status: implementation-complete but policy-rejected and reopened. The atom-deficit
sampler behaves as tested, but a 4.8M-atom logical epoch sees only about 5.8% of the
selected training atoms. That contradicts the required meaning of an epoch: every
selected protein, RNA, and UniMol sample must be consumed once before the epoch ends.
The evidence below is retained as a record of what was tested, not as approval for a
long run.

- [x] Resolve weights summing to 99% versus an exact 55/45 hierarchical policy.
- [x] Define the effective atom budget that constitutes one epoch.
- [x] Implement atom-deficit quotas, not graph-count proportions.
- [x] Remove the ten-slot `max(1, int(...))` distortion.
- [x] Define intentional repeat/undersampling behavior per domain.
- [x] Bound local domain mixing without violating epoch atom quotas.
- [x] Log requested/achieved atoms plus unique/repeated samples per domain.
- [x] Test fast, full, and every enabled single-domain configuration.

Policy: use explicit normalized weights `protein=30`, `rna=25`, `unimol=45`.
One fast logical epoch is 700,000 requested atoms and exactly 140 train batches;
one full-development logical epoch is 4,800,000 requested atoms and exactly 450
train batches. Whole graphs are selected by normalized atom deficit. A domain may
cycle only after its unique train samples are exhausted and only until its quota is
closed. Fixed batch counts are reached by splitting packed batches, never graphs,
so this step creates no new samples, atoms, or repetitions.

Evidence: the current-code fast run completed three epochs with exit code 0 and
exactly 140/140 train batches per epoch. Requested/actual atom counts were
700,000/700,653, 700,000/704,735, and 700,000/703,620. Achieved domain ratios were
29.98/25.06/44.96%, 30.10/25.20/44.70%, and 29.99/25.24/44.77%; all three epochs
reported zero repeated samples in every domain. Train total loss decreased
5.040 -> 4.510 -> 4.350 and the best validation loss decreased
4.645 -> 4.371 -> 4.324 -> 4.184 -> 4.128. The final RNA C1' recall was 0.9908
and RNA BB was 0.9954; protein BB was 1.0000. The log is
`logs/August2026/e5_fixed_batch_final_fast_20260816_1620.log`; the best artifact is
`/tmp/mind_e5_fixed_batch_final_output/best-checkpoint-epoch=02-val_total_loss=4.1280.ckpt`.

The adjacent sampler/filter/vocabulary suite passes 20/20 tests. It covers exact
atom quotas, bounded/no-cycle behavior, whole-graph packing, exact train/validation/
test plan lengths, epoch propagation, a minimal Lightning optimizer-step count,
single-domain/empty/single-sample modes, selection-keyed index-map caches, and E3
limit guards. `py_compile` and `git diff --check` also pass. Metadata-only plans for
the full-development selection produced exactly 450 batches in three consecutive
epochs, with RNA repeats bounded to 8/7/5 and no protein or UniMol repeats. Commit:
pending.

### E6 — Correct batch statistics and measured performance telemetry

Status: metric correctness complete; performance implementation reopened. Per-batch
coverage must remain exact, but the current callback performs graph-by-graph GPU
reductions and `.item()` synchronizations and emits a large table plus a compact line
for every batch. This is not an acceptable full-run implementation. The replacement
must preserve exact per-batch records while vectorizing aggregation and separating
recording frequency from console/W&B emission frequency.

- [x] Store the per-domain statistics that the end-of-run callback aggregates.
- [x] Remove broad silent exception swallowing; report actionable callback failures.
- [x] Remove hard-coded 99.97% cache-hit and 3.5-4.0 it/s claims.
- [x] Measure atoms/s, edges/s, graphs/s, data-wait, and step p50/p90.
- [x] Log graph-size and batch-size quantiles separately.
- [x] Measure real cache hit/miss/load time before claiming cache locality.
- [x] Follow the explicit user decision to retain every-batch composition output and
  add one compact measured telemetry line, rather than silently reducing evidence.
- [x] Add callback aggregation and metric-denominator tests.

Evidence: callback tests prove exact 3/4-node protein/RNA denominators, graph versus
batch quantiles, measured throughput/cache output, and actionable failure propagation.
The three-epoch fast run tracked exactly 140 batches per epoch and measured an epoch-2
cache rate of 99.99%, 11,783 atoms/s, 331,023 edges/s, and 201 graphs/s. The final
20-step synchronized benchmark also reports whole-template and edge-rebuild p50/p90.
Commit: pending.

### E7 — Vectorized V-template hot path

Status: complete for the user-approved PT-unchanged implementation. Numeric roles are
derived on first graph access, retained in an in-memory metadata cache, and collated
without modifying persisted PT files. A future PT schema change is unnecessary unless
full-scale profiling shows this one-time derivation is material.

- [x] Profile the whole template stage, not only targeted edge rebuild.
- [x] Precompute numeric domain, slot, ownership, eligibility, and anchor metadata.
- [x] Remove string parsing, full-node `.cpu().tolist()`, and Python node loops from
  the per-batch template hot path; first-access parsing is cached in RAM.
- [x] Apply masked local-frame transforms with batched tensor operations.
- [x] Replace all-graph `cdist` behavior with a targeted graph-local KNN kernel.
- [x] Prove mapping/mask/anchor and nearest-edge equivalence in focused tests, then
  preserve the real-data chemistry gates in the fast run.
- [x] Benchmark the E5 baseline and vectorized code with the identical seed, IDs,
  20-step plan, GPU, and five-step warmup. Templates-off was re-scoped because it
  changes model inputs rather than isolating this implementation.
- [x] Preserve protein CB, protein V, RNA C1', RNA V, SCr, and BaseR gates.

Evidence: the focused numeric mapping and dense-nearest edge tests pass. Across the
identical 20-step benchmarks, median compute step changed from 0.3931 s to 0.3878 s
(-1.4%); mean compute changed from 0.3765 s to 0.3917 s (+4.1%), and total fit time
changed from 14.01 s to 14.76 s (+5.3%) while every-batch logging was added. This is
not the hypothesized extreme regression. The vectorized run measured template p50
35.8 ms and edge-rebuild p50 17.2 ms. Peak allocated memory was unchanged at 22.48 GB.
The fast validation ended with protein CB recall 1.0000, protein V recall 0.8665,
protein SCr 0.6809, RNA C1' recall 0.9954, RNA V recall 0.9840, and BaseR 0.5236.
Commit: pending.

### G1 — Corrected fast multi-domain validation

Status: complete under the temporary RNA chunk-range decision.

- [x] Run the repo `validate-feature` fast training workflow.
- [x] Use deterministic IDs from every enabled domain.
- [x] Assert no oversized graph or batch-policy violation.
- [x] Assert no missing/cut epoch plan and `len == yielded batches`.
- [x] Assert achieved atom-ratio tolerance and repetition counts.
- [x] Verify finite losses, mask counts, template counters, and metric denominators.
- [x] Compare CB/V/C1'/SCr/BaseR against the Virtual V1 reference.
- [x] Record command, log, runtime, atoms/s, peak VRAM, and pending commit state.

Evidence: `core/pretraining_config_fast.yaml` completed 3/3 epochs and exactly 140/140
batches each epoch. Train loss fell 5.040 -> 4.550 -> 4.380; best validation loss was
4.1434 versus the E5 reference 4.1280. Epoch-2 atom ratios were protein/RNA/UniMol
29.99/25.24/44.77%, with no reported domain repeats. The log is
`logs/August2026/e6_e7_fast_20260816.log`; the best checkpoint is
`/tmp/mind_e6_e7_fast_output/best-checkpoint-epoch=02-val_total_loss=4.1434.ckpt`.
The adjacent unittest suite passes 24/24, Virtual stages 0-4 pass 61/61, py_compile
and `git diff --check` pass. The final synchronized 20-step report is
`/tmp/mind_e6_e7_final_bench20.json`. Commits: pending.

### G2 — Corrected one-full-epoch pilot before long training

Status: pending and re-scoped. Dependencies: corrective items C1-C6 below and a new
fast gate. The previous G1 run proves chemistry and code execution only for the now
rejected 4.8M-atom epoch policy.

- [ ] Run exactly one full-pass epoch: every selected train index once, no cycling.
- [ ] Run one full validation at the epoch boundary, not four intra-epoch validations.
- [ ] Compare atoms/s, edges/s, graphs/s, graph quantiles, and wall time to June and
  the fixed-batch microbenchmarks.
- [ ] Confirm per-domain `selected == available`, `unique == selected`, and
  `repeated == 0` for train.
- [ ] Confirm the validation set and deterministic masks are fixed and leak-free.
- [ ] Confirm the safe attention backend is active and attention Q/K/V gradients are
  finite and nonzero.
- [ ] Confirm W&B visibility, finite losses, and real-only chemistry metrics.
- [ ] Produce a trustworthy wall-time estimate for 50 and 100 epochs.
- [ ] Obtain an explicit GO decision before scheduling the long run.

Evidence: pending.

## 2026-08-17 corrective audit and parallel execution plan

This section supersedes the *policy conclusions* of E5/G1 and the *performance
conclusion* of E6. It does not erase their historical test evidence. E4 is still
deferred, so this report is not complete and must not be replaced or archived yet.

### Corrections to earlier explanations

The current validation set did not grow relative to the closest June full baseline.
The earlier comparison to 50k-105k-graph April/May experiments was not the relevant
comparison for the June run requested by the user.

| Measurement | June baseline | Current GPU1 run | Result |
|---|---:|---:|---|
| Total graphs | 908,446 | 899,429 | Current is 0.99x, not larger |
| Validation graphs | 90,844 | 89,942 | Current is slightly smaller |
| Actual validation batches | 2,410 | 2,068 | Current has 14.2% fewer batches |
| Validations observed | 100 / 100 epochs | 90 by partial epoch 26 | June effectively ran 1/epoch; current runs 3-4/epoch |
| Mean single-validation time | 635.2 s (10m35s) | 940.3 s (15m40s) | Current is 48.0% slower |
| Mean time per validation batch | 0.264 s | 0.455 s | Current is 72.6% slower |

Both configs contain `val_check_interval: 0.25`, but they did not behave equivalently.
The June train sampler reported 60,563 batches while yielding about 19,329. Lightning
therefore reached only the first nominal 25% validation boundary before the iterator
ended. The corrected sampler reports its real length, so `0.25` now triggers all four
validation boundaries. Four validations explain the large *epoch-total* validation
cost, but they do not explain why one current validation is 48% slower. C4 below owns
that separate regression; reducing the validation dataset must not be used to hide it.

### Corrected target dataset

All 67 production RNA output chunks can be filtered using the existing immutable-PT
filter with `num_nodes <= 5000`. This operation does not rerun the RNA adapter, 23-slot
construction, or edge generation. It reads existing PTs, selects unchanged graphs,
re-collates them into new PT containers, reloads them, and verifies tensors/metadata.

| Domain | Graphs | Nodes | Natural node share |
|---|---:|---:|---:|
| Protein, chunks 0-9 | 40,000 | 79,281,230 | 66.3% |
| UniMol, numeric chunks 0-9 | 858,663 | 22,971,162 | 19.2% |
| RNA, all 67 outputs filtered to <=5k | 8,526 | 17,267,580 | 14.5% |
| Total | 907,189 | 119,519,972 | 100% |

The RNA filter retains 824,368,203 edges. Estimated new derived storage is 17-18 GB;
keeping the existing 1.5 GB five-chunk subset makes `/home/yusuf/data/rna_small`
about 18.5-20 GB total. The 211 GB source PT corpus remains unchanged. Estimated
filter/re-collate/validation time is 25-90 minutes depending on disk contention; use
30-60 minutes as the normal planning range.

This total is deliberately useful: the June baseline had 908,446 graphs and
120,436,742 metadata nodes. The corrected target is within about 0.1% by graph count
and 0.8% by node count, while enforcing the 5k RNA safety limit.

### Open corrective items

#### C1 (P0) — Restore full-pass epoch semantics

Problem: the 4.8M atom quota selects only about 5.8% of the current train atoms per
epoch, including about 2.3% of protein and 11.8% of UniMol. Epoch-to-epoch reshuffling
does not guarantee complete coverage.

Solution:

- disable the atom-quota boundary for the full configuration;
- consume every selected train index exactly once per epoch;
- set `cycle_short_domains=false` and do not repeat RNA;
- interleave domains by proportional completion so they progress across the epoch
  without a late UniMol-only tail;
- treat the natural 66.3/19.2/14.5 node mix as data coverage, not a sampling target;
- if later needed, change loss weights rather than repeating data.

Affected code/config: `core/train_pretrain.py`, full/fast YAML policies, and sampler
tests. PT regeneration is not required. Complexity: low-medium; the sampler already
has a single-pass mixed-stream path, but the loader currently does not expose the
required no-cycle policy safely.

Acceptance:

- `len(plan) == len(list(iter(sampler)))`;
- flattened train indices contain no duplicates and equal the split's complete index
  set;
- domain report says `selected == available`, `unique == selected`, `repeated == 0`;
- epoch ends only after all selected domains are exhausted;
- two epochs reshuffle order without changing membership.

#### C2 (P0) — Expand safe RNA coverage without long-RNA E4

Problem: the five-chunk derived set has only 766 graphs / 1.51M nodes and comes only
from the beginning of source group 0. RNA is about 1.5% of current selected nodes.

Solution: create a new immutable all-output derived base under
`/home/yusuf/data/rna_small`, filter all production chunks at 5k nodes, and leave both
production PTs and the existing five derived chunks untouched. Use all 8,526 retained
graphs once per epoch. This raises RNA to 14.5% without repetition and includes all
five source groups.

Acceptance:

- aggregate totals equal 8,526 graphs, 17,267,580 nodes, and 824,368,203 edges;
- maximum graph size is <=5,000;
- all molecule IDs are unique and source group/local index provenance is retained;
- every output chunk reloads and passes tensor, edge-bound, finite-value, metadata,
  checksum, and source-immutability checks.

#### C3 (P1) — Remove E6 telemetry observer overhead

Problem: `BatchStatisticsCallback._compute_batch_stats()` loops over every graph and
executes `(batch_mapping == graph_idx).sum().item()`. With dozens of small UniMol
graphs this creates dozens of GPU-to-CPU synchronization points per batch. E6 also
prints a detailed table and a telemetry line every batch. June printed the table once
per 25 batches.

Solution:

- compute all graph sizes with one `torch.bincount`;
- transfer the size vector once and aggregate domains on CPU;
- retain an exact record for every batch;
- emit one compact line at an agreed interval and the complete aggregate at epoch end;
- raise Lightning/W&B step logging from every step to a measured safe interval;
- retain immediate, actionable callback failures.

Affected code: `core/batch_statistics_callback.py`, YAML logging frequencies, and
callback tests. Complexity: low-medium.

Acceptance:

- exact parity with existing per-domain graph/atom totals on fixed synthetic batches;
- no per-graph `.item()` or equivalent synchronization loop;
- telemetry-on benchmark adds no more than 5% to a fixed 200-step telemetry-off
  control;
- epoch aggregate still contains every batch, including p50/p90/max and cache data.

#### C4 (P0) — Explain and fix validation regression

Problem: cadence and per-validation throughput both regressed. June effectively ran
one 2,410-batch validation per epoch in 10m35s. Current code runs three to four
2,068-batch validations per epoch, and each takes 11m51s-21m47s (mean 15m40s).
The current validation is slower despite fewer graphs and batches.

Do not assume a smaller validation subset is the root fix. First profile the same
fixed validation IDs/batches with these isolated controls:

1. data-loader-only iteration;
2. safe `flash_varlen` forward/loss without callbacks;
3. add runtime masked-slot templates and targeted edge rebuilding;
4. add per-domain validation losses;
5. add protein/RNA metric callbacks and CPU prediction transfer;
6. repeat under quiet-disk conditions and record cache hit/load telemetry.

Final cadence for the corrected full pilot is one full validation at epoch end
(`val_check_interval: 1.0`). A fixed stratified routine subset remains an optional
later optimization only after the 48% single-validation regression is explained.

Affected code/config may include `core/train_pretrain.py`, validation/test loader
construction, `core/pretraining_model.py`, metric callbacks, and YAML cadence. Begin
with config-only A/B profiling; change code only where measurement identifies the
regression. Complexity: investigation medium, eventual fix unknown until attribution.

Acceptance:

- exactly one validation invocation per epoch in the full pilot;
- a fixed validation plan produces identical IDs and deterministic masks across runs;
- each A/B stage records batches, nodes, edges, graph count, loader wait, forward/loss
  time, callback time, and total wall time;
- recover close to June's per-batch validation throughput or document an unavoidable,
  measured Virtual V1 cost;
- never reduce validation coverage merely to conceal a throughput regression.

#### C5 (P0) — Disable training-unsafe Triton attention

Problem: the merged Triton path contains a forward kernel but no registered backward
implementation. Its output is disconnected from Q/K/V autograd, while
`pretraining_model` defaults the path on and overrides the requested `flash_varlen`
backend. Loss can still fall through residual/equivariant/task paths, so a smoke run
does not prove attention is learning. The same-batch benchmark did not show a speedup.

Immediate config containment:

```yaml
use_triton_flash_attention: false
use_triton_varlen_flash_attention: false
```

Then make the code default safe, add backend-selection tests, assert finite nonzero
Q/K/V gradients, and compare forward/backward outputs against the established
`flash_varlen` implementation before any future Triton training use. Complexity:
low for containment, medium-high for a legitimate Triton backward implementation;
the latter is out of scope for the next baseline.

#### C6 (P1) — Restore visible experiment logging

Problem: the merge changed absent `use_wandb` to mean false, so a config containing
project/run names silently falls back to local CSV.

Solution: set `use_wandb: true` explicitly for the approved full config, print the
resolved logger/backend before model construction, and test both explicit modes.
Complexity: low.

#### C7 (P1) — Re-estimate train time after removing observer effects

June processed about 19,329 train batches at about 3.89 batches/s, roughly 1h23 of
train progress. The current 20-step benchmark measured 0.3878 s median compute and
14.76 s total fit time for 20 steps while every-batch logging was enabled. Runtime
templates account for about 35.8 ms p50 plus 17.2 ms edge rebuild p50, roughly 53 ms
per representative batch; they are a real but insufficient explanation for a 3-5h
epoch.

Do not publish a final epoch estimate from the rejected 30/25/45 quota mix, because
it contains far more small UniMol graphs per batch than the natural full-pass mix.
After C1/C3/C5, benchmark 300-500 deterministic full-plan batches and extrapolate
from measured atoms/s plus domain/graph-size strata. Current planning target after
observer fixes is roughly 1.8-2.8h train plus one measured full validation, but only
G2 may establish the operational estimate.

#### C8 (P2) — Preserve interpretation of existing runs

- GPU1 `e6_e7_full_100ep` is Triton-safe because it started from pre-merge modules,
  but it uses the rejected 4.8M-atom epoch policy. Keep it running only as a learning
  and stability diagnostic; do not report it as full-data epoch training.
- The merged GPU0 run was stopped after the Triton/W&B defects were confirmed. Do not
  compare its learning curve or speed with the safe baseline.
- E4 long-RNA windowing remains deferred. Oversized RNA is excluded, not split.
- Metabolite remains outside the comparison because it was absent from the requested
  baseline.

### Parallel work lanes and dependencies

| Lane | Work | Can run in parallel with | Must wait for |
|---|---|---|---|
| A — Data | C2: filter/validate all 67 RNA chunks | B and C code/unit work | Nothing; avoid GPU timing while heavy I/O is active |
| B — Epoch correctness | C1 sampler/config/tests | A and C | Final metadata totals from A only for integration assertions |
| C — Backend/telemetry | C3, C5, C6 and focused tests | A and B | Nothing for unit tests |
| D — Validation attribution | C4 fixed-batch A/B profile | B code work | C5 containment; quiet disk after A for trustworthy timings |
| E — Integration | full-plan metadata audit and 300-500 step benchmark | Nothing timing-sensitive | A-D pass |
| F — G2 | one corrected full train epoch + one full validation | Nothing on the same GPU/disk | E pass and explicit run approval |

Practical schedule:

1. Start Lane A's read-only-source RNA derivation.
2. In parallel implement/test Lane B and Lane C as separate focused commits.
3. When RNA I/O finishes, run Lane D on a quiet system using fixed IDs.
4. Integrate only after all lane-level tests pass; generate the exact full epoch plan
   without launching training.
5. Run the 300-500 batch timing/gradient gate.
6. Run G2 exactly once.
7. Review G2 with the user before any 50/100-epoch command.

### Planned commit boundaries

Generated RNA PTs and local manifests are artifacts and must not be committed.
Keep code changes reviewable:

1. `Restore full-pass multidomain epoch semantics`
2. `Vectorize multidomain batch telemetry aggregation`
3. `Disable training-unsafe Triton attention by default`
4. `Restore explicit W&B experiment logging`
5. `Make full validation cadence explicit`
6. Validation performance fix, named only after C4 identifies its cause

Per prior user instruction, this audit report stays outside those implementation
commits unless the user explicitly asks to commit documentation.

## Exit criteria before the next long run

- `len(sampler)` exactly equals batches yielded for every loader.
- No graph silently exceeds `max_graph_atoms`.
- Every selected train index is consumed exactly once; sampling does not enforce the
  superseded 30/25/45 atom quotas.
- Epoch membership is complete and stable while ordering changes across epochs.
- Available, selected, unique, and repeated sample counts are logged per domain, with
  `selected == available == unique` and `repeated == 0`.
- p50/p90/max nodes per graph and per batch are logged separately.
- Atoms/s and p50/p90 step time replace raw it/s as the main throughput comparison.
- Protein CB and RNA/protein V regression metrics remain healthy.
- Real-only `SCr`, `BaseR`, residue, and nucleotide metrics have nonzero, stable
  denominators and no cross-domain leakage.
- A corrected one-epoch full run has predictable wall time before committing to
  50-100 epochs.
